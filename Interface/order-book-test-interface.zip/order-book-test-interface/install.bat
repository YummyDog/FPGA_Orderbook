@echo off
rem One-time setup: installs the GUI library. Npcap must be installed separately.
cd /d "%~dp0"
py -3 -m pip install -r requirements.txt
pause
