"""Checks of the wire formats against hand-derived bytes and the ASX spec sizes."""

import struct

import pytest

from obtest import itch
from obtest.frames import (Headers, build_mold, build_udp_frame, frame_length, parse_mold,
                           parse_udp_frame, _checksum)
from obtest.itch import Message
from obtest.model import sample_queue
from obtest.telemetry import (Event, LatencyTracker, cycles_to_ns, decode_event,
                              encode_event, PRICE, ORDER, INPUT, FIFO)


# ------------------------------------------------------------------- ITCH

def test_message_lengths_match_spec():
    # Sums of the field tables in the ASX ITCH spec v3.1.
    expected = {"A": 37, "F": 44, "E": 52, "C": 58, "U": 36, "D": 18, "T": 5}
    for code, length in expected.items():
        assert len(Message(msg_type=code).encode()) == length


def test_add_order_bytes_match_spec_example():
    # Spec 4.1.1: A,251202700,62018a81:000119dd,70578,B,1,100,55000,0,2
    m = Message("A", 251202700, 0x62018A81000119DD, 70578, "B", 1, 100, 55000, 0, 2)
    expected = ("41" "0ef90c8c" "62018a81000119dd" "000113b2" "42" "00000001"
                "0000000000000064" "0000d6d8" "0000" "02")
    assert m.encode().hex() == expected


def test_delete_bytes():
    # Spec 4.1.1: D,029312500,62018a81:000119dd,70578,B   (29312500 = 0x01bf45f4)
    m = Message("D", 29312500, 0x62018A81000119DD, 70578, "B")
    assert m.encode().hex() == "44" "01bf45f4" "62018a81000119dd" "000113b2" "42"


def test_negative_price_is_signed_big_endian():
    m = Message("A", price=-2147483648)
    assert m.encode()[30:34] == b"\x80\x00\x00\x00"


@pytest.mark.parametrize("code", list(itch.MSG_TYPES))
def test_round_trip(code):
    m = Message(code, 123456789, 0xDEADBEEF01020304, 4294922738, "S", 7, 2 ** 40 + 5, -42,
                8192, 3, "AU550", "AU551", 0x00FB30C20000003600000001, 26100, "Y", "N", 1700000000)
    back = itch.decode(m.encode())
    for name in itch.FIELDS_BY_TYPE[code]:
        assert getattr(back, name) == getattr(m, name), name


def test_validation_messages():
    with pytest.raises(ValueError, match="Quantity"):
        Message("A", quantity=2 ** 64).encode()
    with pytest.raises(ValueError, match="Side"):
        Message("A", side="X").encode()
    with pytest.raises(ValueError, match="Participant"):
        Message("F", participant_id="TOOLONGID").encode()


def test_order_id_text():
    assert itch.parse_order_id("62018a81:000119dd") == 0x62018A81000119DD
    assert itch.parse_order_id("0x1F") == 0x1F
    assert itch.format_order_id(0x62018A81000119DD) == "62018a81:000119dd"
    with pytest.raises(ValueError):
        itch.parse_order_id("xyz")
    with pytest.raises(ValueError):
        itch.parse_order_id("1" * 17)


# ----------------------------------------------------------- Mold and frames

def test_mold_layout():
    payload = build_mold("ABC", 0x0102030405060708, 2, [b"\xAA", b"\xBB\xCC"])
    assert payload[:10] == b"ABC       "
    assert payload[10:18] == bytes(range(1, 9))
    assert payload[18:20] == b"\x00\x02"
    assert payload[20:] == b"\x00\x01\xAA" + b"\x00\x02\xBB\xCC"
    assert parse_mold(payload) == ("ABC", 0x0102030405060708, 2, [b"\xAA", b"\xBB\xCC"])


def test_mold_count_can_disagree_with_messages():
    payload = build_mold("S", 1, 5, [b"\x00"])
    assert struct.unpack(">H", payload[18:20])[0] == 5


def test_sample_queue_sizes_and_sequences():
    q = sample_queue()
    # 14 Ethernet + 20 IPv4 + 8 UDP + 20 Mold + (2 + length) per message
    assert [p.frame_length() for p in q.packets] == [101, 121, 82]
    assert [(p.sequence, p.count) for p in q.packets] == [(1, 1), (2, 2), (4, 1)]
    assert all(len(q.build_frame(p)) == p.frame_length() for p in q.packets)
    assert frame_length(20 + 39 + 20 + 39) == 160


def test_auto_numbering_respects_manual_packets():
    q = sample_queue()
    q.packets[0].sequence = 100
    q.packets[1].auto = False
    q.packets[1].sequence, q.packets[1].count = 7, 9
    q.renumber()
    assert [(p.sequence, p.count) for p in q.packets] == [(100, 1), (7, 9), (16, 1)]


def test_frame_headers_and_checksums():
    h = Headers("01:02:03:04:05:06", "0a:0b:0c:0d:0e:0f", "10.1.2.3", "192.168.7.9", 4660, 22136)
    payload = bytes(range(40))
    f = build_udp_frame(h, payload, ip_id=0x1234)
    assert f[0:6] == bytes([1, 2, 3, 4, 5, 6])              # destination MAC first
    assert f[6:12] == bytes([10, 11, 12, 13, 14, 15])
    assert f[12:14] == b"\x08\x00"
    ip = f[14:34]
    assert ip[0] == 0x45 and ip[9] == 17
    assert struct.unpack(">H", ip[2:4])[0] == 20 + 8 + 40
    assert ip[12:16] == bytes([192, 168, 7, 9]) and ip[16:20] == bytes([10, 1, 2, 3])
    assert _checksum(ip) == 0                               # valid header checksum
    udp = f[34:42]
    assert struct.unpack(">HHH", udp[:6]) == (22136, 4660, 48)
    pseudo = ip[12:20] + struct.pack(">BBH", 0, 17, 48)
    assert _checksum(pseudo + f[34:34 + 48]) == 0           # valid UDP checksum
    parsed = parse_udp_frame(f)
    assert parsed.payload == payload and parsed.dst_port == 4660 and parsed.src_port == 22136


def test_short_frames_are_padded_but_lengths_are_true():
    f = build_udp_frame(Headers(), b"\x01\x02\x03")
    assert len(f) == 60
    assert parse_udp_frame(f).payload == b"\x01\x02\x03"


def test_parse_ignores_non_udp():
    assert parse_udp_frame(b"\x00" * 60) is None
    arp = b"\xff" * 6 + b"\x02" * 6 + b"\x08\x06" + b"\x00" * 46
    assert parse_udp_frame(arp) is None


def test_bad_addresses_are_reported():
    with pytest.raises(ValueError, match="MAC"):
        build_udp_frame(Headers(dst_mac="nope"), b"")
    with pytest.raises(ValueError, match="IP"):
        build_udp_frame(Headers(dst_ip="300.1.1.1"), b"")
    with pytest.raises(ValueError, match="Port"):
        build_udp_frame(Headers(dst_port=70000), b"")


# ---------------------------------------------------------------- telemetry

def _bits(etype, op, data, side, ts):
    """Independent construction: write the 87 bits out as text, spare bit last."""
    text = f"{etype:02b}{op:02b}{data:064b}{side:01b}{ts:018b}" + "0"
    assert len(text) == 88
    return int(text, 2).to_bytes(11, "big")


def test_decode_field_positions():
    payload = _bits(ORDER, 3, 0x62018A81000119DD, 1, 0x2ABCD)
    ev = decode_event(payload)
    assert (ev.etype, ev.op, ev.data, ev.side, ev.ts) == (ORDER, 3, 0x62018A81000119DD, 1, 0x2ABCD)
    assert ev.type_name == "Order" and ev.op_name == "DELETE" and ev.side_name == "Sell"
    assert ev.describe_data() == "62018a81:000119dd"


def test_spare_bit_is_at_the_bottom():
    # Timestamp 1 sits one bit above the spare bit: last byte is 0b00000010.
    assert decode_event(b"\x00" * 10 + b"\x02").ts == 1
    # The spare bit itself is ignored.
    assert decode_event(b"\x00" * 10 + b"\x01") == Event(b"\x00" * 10 + b"\x01", 0, 0, 0, 0, 0)
    # Type is the top two bits of the first byte, op the next two.
    assert decode_event(b"\xC0" + b"\x00" * 10).etype == FIFO
    assert decode_event(b"\x80" + b"\x00" * 10).etype == INPUT
    assert decode_event(b"\x30" + b"\x00" * 10).op == 3
    # Side is bit 18 of the event, bit 19 of the 88: byte 8, value 0x08.
    assert decode_event(b"\x00" * 8 + b"\x08\x00\x00").side == 1
    # Data's lowest bit is bit 19 of the event, bit 20 of the 88: byte 8, value 0x10.
    assert decode_event(b"\x00" * 8 + b"\x10\x00\x00").data == 1


def test_price_event_data_split():
    ev = decode_event(_bits(PRICE, 0, (100 << 32) | 55000, 0, 5))
    assert ev.describe_data() == "qty 100 · price 55000"


def test_encode_is_inverse_of_decode():
    for args in [(PRICE, 0, 0, 0, 0), (FIFO, 3, 2 ** 64 - 1, 1, 2 ** 18 - 1),
                 (INPUT, 1, 0x0123456789ABCDEF, 0, 77)]:
        assert encode_event(*args) == _bits(*args)
        ev = decode_event(encode_event(*args))
        assert (ev.etype, ev.op, ev.data, ev.side, ev.ts) == args


def test_decode_uses_first_eleven_bytes_and_rejects_short():
    payload = _bits(ORDER, 0, 5, 0, 9)
    assert decode_event(payload + b"\x00" * 7).data == 5
    with pytest.raises(ValueError):
        decode_event(payload[:10])


def test_latency_rule():
    t = LatencyTracker()
    ev = lambda etype, ts: Event(b"", etype, 0, 0, 0, ts)
    assert t.update(ev(PRICE, 50)) is None            # nothing to measure from yet
    assert t.update(ev(INPUT, 100)) == 0              # reference
    assert t.update(ev(FIFO, 103)) == 3
    assert t.update(ev(PRICE, 120)) == 20
    assert t.update(ev(INPUT, 200)) == 0              # new input restarts it
    assert t.update(ev(ORDER, 207)) == 7
    # 18-bit counter wraps: 262140 -> 4 is 8 cycles.
    assert t.update(ev(INPUT, 262140)) == 0
    assert t.update(ev(PRICE, 4)) == 8


def test_cycles_to_ns():
    assert cycles_to_ns(10, 156.25) == pytest.approx(64.0)   # 6.4 ns per cycle
    assert cycles_to_ns(None, 156.25) is None
    assert cycles_to_ns(5, 0) is None
