"""Drives the real window without a display: edit, fire, log, save."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtWidgets import QApplication

from obtest.gui.main_window import MainWindow
from obtest.gui.widgets import QSS
from obtest.model import AppState


@pytest.fixture(scope="module")
def app():
    a = QApplication.instance() or QApplication([])
    a.setStyle("Fusion")
    a.setStyleSheet(QSS)
    return a


@pytest.fixture
def win(app, tmp_path):
    w = MainWindow(tmp_path)
    w.show()
    app.processEvents()
    yield w
    w.close()


def commit(field, text):
    """Type into a text box and leave it, as a user would."""
    field.setText(text)
    field.editingFinished.emit()


def test_starts_connected_to_the_stand_in_with_the_sample_queue(win):
    assert win.engine.connected and "Simulated" in win.status.text()
    assert win.queue_page.plist.count() == 3
    assert "seq 2 · 2 msgs · 121 bytes" in win.queue_page.plist.item(1).text()


def test_fire_queue_fills_the_log(win, app):
    page = win.queue_page
    page.fire_queue()
    win.pump()
    assert page.log_model.rowCount() == 16
    assert page.events_chip.text() == "16 events"
    since = [page.log_model.index(r, 6).data() for r in range(4)]
    assert since[0] == "Reference" and since[1] == "19.2 ns · 3 cyc"
    assert all("Sent" in page.plist.item(i).text() for i in range(3))
    # A second fire starts a fresh run and a fresh log.
    page.fire_queue()
    win.pump()
    assert page.log_model.rowCount() == 16


def test_editing_a_message_updates_the_packet(win):
    page = win.queue_page
    commit(page.m_fields["quantity"], "250")
    commit(page.m_fields["price"], "56000")
    commit(page.m_fields["order_id"], "aaaaaaaa:bbbbbbbb")
    m = win.engine.state.queue.packets[0].messages[0]
    assert (m.quantity, m.price, m.order_id) == (250, 56000, 0xAAAAAAAABBBBBBBB)
    assert page.table.item(0, 5).text() == "250"
    assert page.table.item(0, 2).text() == "aaaaaaaa:bbbbbbbb"


def test_bad_input_is_flagged_and_not_stored(win):
    page = win.queue_page
    before = win.engine.state.queue.packets[0].messages[0].price
    commit(page.m_fields["price"], "abc")
    assert page.m_fields["price"].property("invalid") is True
    assert win.engine.state.queue.packets[0].messages[0].price == before
    assert "Price" in win.statusBar().currentMessage()
    commit(page.h_fields["dst_mac"], "not-a-mac")
    assert page.h_fields["dst_mac"].property("invalid") is True


def test_message_type_changes_the_visible_boxes_and_the_size(win):
    page = win.queue_page
    assert not page.m_fields["match_id"].isVisibleTo(page)
    page.f_type.setCurrentIndex(page.f_type.findData("C"))
    assert win.engine.state.queue.packets[0].messages[0].msg_type == "C"
    assert page.m_fields["match_id"].isVisibleTo(page)
    assert page.m_fields["trade_price"].isVisibleTo(page)
    assert not page.m_fields["book_position"].isVisibleTo(page)
    # 14 + 20 + 8 + 20 + 2 + 58
    assert "122-byte frame" in page.size_label.text()


def test_auto_numbering_and_manual_override(win):
    page = win.queue_page
    q = win.engine.state.queue
    commit(page.f_sequence, "500")
    assert [p.sequence for p in q.packets] == [500, 501, 503]
    page.add_message()
    assert q.packets[0].count == 2 and [p.sequence for p in q.packets] == [500, 502, 504]
    assert page.f_count.isReadOnly()
    page.auto.setChecked(False)
    assert not page.f_count.isReadOnly()
    commit(page.f_count, "9")
    assert q.packets[0].count == 9 and q.packets[1].sequence == 509
    # The header really carries the typed count.
    assert q.packets[0].payload()[18:20] == b"\x00\x09"


def test_per_packet_headers(win):
    page = win.queue_page
    q = win.engine.state.queue
    commit(page.h_fields["dst_port"], "40000")
    assert q.shared_headers.dst_port == 40000
    page.same_headers.setChecked(False)
    assert all(p.headers.dst_port == 40000 for p in q.packets)
    page.plist.setCurrentRow(1)
    commit(page.h_fields["dst_port"], "41000")
    commit(page.h_fields["dst_mac"], "AA-BB-CC-00-11-22")
    assert [p.headers.dst_port for p in q.packets] == [40000, 41000, 40000]
    frame = q.build_frame(q.packets[1])
    assert frame[:6] == bytes.fromhex("aabbcc001122") and frame[36:38] == (41000).to_bytes(2, "big")


def test_queue_operations(win):
    page = win.queue_page
    q = win.engine.state.queue
    page.add_packet()
    assert len(q.packets) == 4 and page.pi == 1
    page.duplicate_packet()
    assert len(q.packets) == 5
    page.move_packet(-1)
    assert page.pi == 1
    page.remove_packet()
    assert len(q.packets) == 4
    page.plist.setCurrentRow(0)
    page.duplicate_message()
    page.remove_message()
    assert len(q.packets[0].messages) == 1


def test_fire_next_selects_the_packet_it_sent(win):
    page = win.queue_page
    page.fire_next()
    win.pump()
    assert page.pi == 0 and page.log_model.rowCount() == 4
    page.fire_next()
    win.pump()
    assert page.pi == 1 and page.log_model.rowCount() == 12


def test_firing_with_a_pause_uses_the_timer(win, app):
    import time
    win.engine.state.settings.packet_gap_ms = 20
    page = win.queue_page
    page.fire_queue()
    assert not page.fire_btn.isEnabled()
    deadline = time.time() + 3
    while not page.fire_btn.isEnabled() and time.time() < deadline:
        app.processEvents()
        time.sleep(0.005)
    win.pump()
    assert page.fire_btn.isEnabled() and page.log_model.rowCount() == 16


def test_not_connected_is_reported(win):
    win.toggle_connection()
    assert not win.engine.connected
    win.queue_page.fire_queue()
    assert "Not connected" in win.statusBar().currentMessage()
    win.send_reset()
    assert "Not connected" in win.statusBar().currentMessage()


def test_configurations_and_clock(win, app):
    page = win.params_page
    commit(page.f_clock, "322.265625")
    assert win.engine.state.config.clock_mhz == 322.265625
    assert page.cycle_label.text() == "3.103 ns per cycle"
    commit(page.f_addr, "15")
    commit(page.f_tables, "2")
    assert page.entries_label.text() == "32,768 entries per table · 65,536 entries in total"
    page.add_config()
    commit(page.f_name, "Two tables")
    assert page.use_btn.isEnabled()          # the new one is not in use yet
    page.use_config()
    assert win.engine.state.config.name == "Two tables"

    win.queue_page.fire_queue()
    win.pump()
    row = win.queue_page.log_model.rows[1]
    assert row.since_ns == pytest.approx(3 * 1000 / 322.265625)
    win.engine.end_run()
    page.refresh_stats()
    names = [page.stats.item(r, 0).text() for r in range(page.stats.rowCount())]
    assert names == ["Two tables"]


def test_settings_are_saved(win, tmp_path):
    commit(win.connection_page.f_port, "31000")
    commit(win.connection_page.f_reset_payload, "de ad be ef")
    win._save()
    state = AppState.load(tmp_path)
    assert state.settings.telemetry_port == 31000
    assert state.settings.reset_payload() == bytes.fromhex("deadbeef")
