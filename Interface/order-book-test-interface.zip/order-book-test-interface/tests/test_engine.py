"""End-to-end checks through the software stand-in, and over real capture on loopback."""

import csv
import json
import os
import struct
import sys
import threading
import time

import pytest

from obtest.engine import Engine
from obtest.runlog import latency_by_config
from obtest.simfpga import SimFpga


def _pcap_records(path):
    data = path.read_bytes()
    assert struct.unpack("<I", data[:4])[0] == 0xA1B2C3D4
    pos, frames = 24, []
    while pos < len(data):
        _, _, incl, orig = struct.unpack("<IIII", data[pos:pos + 16])
        frames.append(data[pos + 16:pos + 16 + incl])
        pos += 16 + incl
    return frames


def test_fire_queue_logs_events(tmp_path):
    eng = Engine(tmp_path)
    eng.connect()
    assert eng.fire_all() == 3
    rows = eng.pump()

    # The stand-in emits input, FIFO, order and price for each of the 4 messages.
    assert [r.event for r in rows] == ["Input", "FIFO", "Order", "Price"] * 4
    assert [r.op for r in rows if r.event == "Order"] == ["ADD", "DELETE", "ADD", "DELETE"]
    assert all(r.side == "Buy" for r in rows if r.event in ("Order", "Price"))
    assert [r.data_decoded for r in rows if r.event == "Price"] == [
        "qty 100 · price 55000", "qty 0 · price 55000", "qty 90 · price 55100",
        "qty 0 · price 55100"]
    assert all(r.data_decoded == "62018a81:000119dd" for r in rows if r.event == "Order")

    # Latency rule: inputs are the reference, everything else counts from the last one.
    for i in range(0, 16, 4):
        inp, fifo, order, price = rows[i:i + 4]
        assert inp.is_reference and inp.since_cycles == 0
        assert fifo.since_cycles == (fifo.ts - inp.ts) % 2 ** 18 == 3
        assert 0 < order.since_cycles < price.since_cycles
        assert price.since_ns == pytest.approx(price.since_cycles * 6.4)

    assert all(p.status == "sent" for p in eng.state.queue.packets)
    run_dir = eng.run.dir
    eng.disconnect()

    with open(run_dir / "events.csv", newline="", encoding="utf-8") as f:
        saved = list(csv.DictReader(f))
    assert len(saved) == 16
    assert saved[2]["raw_payload_hex"] == rows[2].raw_hex and len(rows[2].raw_hex) == 22
    assert len(_pcap_records(run_dir / "capture.pcap")) == 3 + 16
    meta = json.loads((run_dir / "run.json").read_text())
    assert meta["config"]["name"] == "Baseline" and len(meta["queue"]["packets"]) == 3

    stats = latency_by_config(tmp_path, "Price")
    assert stats[0]["config"] == "Baseline" and stats[0]["runs"] == 1 and stats[0]["events"] == 4
    assert stats[0]["worst_ns"] >= stats[0]["median_ns"] > 0
    assert latency_by_config(tmp_path, "All")[0]["events"] == 12       # inputs not counted


def test_fire_next_steps_and_restarts(tmp_path):
    eng = Engine(tmp_path)
    eng.connect()
    assert eng.fire_next() == 0
    first_run = eng.run.name
    assert len(eng.pump()) == 4
    assert eng.fire_next() == 1 and eng.run.name == first_run
    assert len(eng.pump()) == 8
    assert eng.fire_next() == 2
    eng.pump()
    assert eng.next_queued() is None
    assert eng.fire_next() == 0 and eng.run.name != first_run     # queue restarts, new run
    eng.disconnect()


def test_reset_packet_reaches_the_stand_in(tmp_path):
    eng = Engine(tmp_path)
    eng.state.settings.reset_first = True
    eng.connect()
    eng.fire_all()
    assert eng.transport.fpga.resets == 1
    assert eng.run.sent_frames == 4                     # reset + 3 packets
    eng.disconnect()


def test_state_survives_restart(tmp_path):
    eng = Engine(tmp_path)
    eng.state.queue.packets[0].messages[0].quantity = 777
    eng.state.settings.telemetry_port = 4242
    eng.state.configs[0].clock_mhz = 322.265625
    eng.save()
    again = Engine(tmp_path)
    assert again.state.queue.packets[0].messages[0].quantity == 777
    assert again.state.settings.telemetry_port == 4242
    assert again.state.configs[0].clock_mhz == 322.265625


def test_bad_header_names_the_packet(tmp_path):
    eng = Engine(tmp_path)
    eng.state.queue.shared_headers.dst_mac = "zz"
    eng.connect()
    with pytest.raises(ValueError, match="Packet 1"):
        eng.fire_all()
    eng.disconnect()


def test_not_connected_is_reported(tmp_path):
    with pytest.raises(RuntimeError, match="Not connected"):
        Engine(tmp_path).fire_all()


@pytest.mark.skipif(sys.platform != "linux" or os.geteuid() != 0,
                    reason="needs raw capture on the Linux loopback adapter")
def test_real_capture_path_on_loopback(tmp_path):
    """Same run, but through libpcap on 'lo' with the stand-in on its own handles."""
    from obtest import pcapio

    assert any(name == "lo" for name, _ in pcapio.list_devices())
    fpga = SimFpga(30002, 30003, b"RESET")
    rx = pcapio.Receiver("lo", "udp and not dst port 30002")
    tx = pcapio.Sender("lo")
    stop = threading.Event()

    def serve():
        while not stop.is_set():
            item = rx.read()
            if item is not None:
                for reply in fpga.handle_frame(item[1]):
                    tx.send(reply)

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    eng = Engine(tmp_path)
    eng.state.settings.device = "lo"
    eng.state.settings.reset_first = True
    try:
        eng.connect("loopback")
        time.sleep(0.2)
        eng.fire_all()
        rows, deadline = [], time.time() + 5
        while len(rows) < 16 and time.time() < deadline:
            rows += eng.pump()
            time.sleep(0.05)
        assert [r.event for r in rows] == ["Input", "FIFO", "Order", "Price"] * 4
        assert fpga.resets == 1
        assert eng.transport.error() is None
    finally:
        eng.disconnect()
        stop.set()
        thread.join(timeout=2)
        rx.close()
        tx.close()
