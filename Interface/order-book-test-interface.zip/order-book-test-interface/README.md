# Order Book Test Interface

Sends ASX ITCH packets (Ethernet → IPv4 → UDP → MoldUDP64 → ITCH) to the FPGA
and logs the event packets it sends back, with latency measured from each
input event.

Status: built and tested on Linux against a software stand-in for the FPGA,
including real raw-frame send and capture on the loopback adapter. It has
**not** been run on Windows or against the ConnectX-5 or the real FPGA.

## Setup on Windows

1. Install Python 3.10 or newer from python.org (tick "Add python.exe to PATH").
2. Install Npcap from https://npcap.com. The default options are fine. If you
   tick "Restrict Npcap driver's access to Administrators only", run the app as
   administrator.
3. Double-click `install.bat` (installs PySide6, the GUI library).
4. Double-click `run.bat`.

On Linux: `pip install -r requirements.txt`, install `libpcap`, and run
`sudo python run.py` (raw capture needs root).

## First run

The app starts connected to **Simulated FPGA (no hardware)** with a sample
queue (the add / amend / delete example from the ASX spec). Press **Fire
queue** to see events arrive in the log. The simulated latencies are made up.

To use the card: **Connection** page → choose the ConnectX adapter → set the
UDP destination port your FPGA sends events to → **Connect**.

Before the first real run, set these, because the defaults are placeholders:

| Where | What |
|---|---|
| Packet queue → headers | destination and source MAC, IP and port |
| Packet queue → Session | the MoldUDP64 session your design expects |
| Connection → FPGA events | UDP destination port of the event packets |
| Connection → Reset packet | port and payload your reset module looks for |
| FPGA parameters → Timing | clock frequency of the timestamp counter |

## Pages

**Packet queue**

- Left: the queue. *Fire queue* starts a new run and sends every packet in
  order. *Fire next* sends one packet per press.
- Middle: the selected packet (session, sequence number, message count,
  headers, messages) and the event log.
- Right: every field of the selected message. Supported messages: Add Order
  (A), Add Order with participant (F), Order Executed (E), Order Executed with
  price (C), Order Replace (U), Order Delete (D), Seconds (T).
- With *Fill sequence number and message count automatically* ticked, the
  count follows the number of messages and each sequence number follows on
  from the previous packet. Untick it to type any values; the header then
  carries exactly what you typed, even if it disagrees with the contents.
- Numbers accept decimal or `0x` hex. Order IDs are hex, e.g.
  `62018a81:000119dd`.

**FPGA parameters**

Describes each FPGA build. Nothing here is sent to the FPGA. The clock
frequency converts cycles to nanoseconds; table count, address length, hash
function and any other parameters are labels saved with each run. *Latency by
configuration* summarises every saved run.

**Connection**

Adapter, event port, pause between packets, reset packet and the data folder.

## Event packets from the FPGA

One event per UDP packet. The payload is 11 bytes, most significant byte
first, holding 87 bits with the spare bit at the bottom (`event & '0'`):

| Bits of event | Field |
|---|---|
| 86–85 | type: 00 price, 01 order, 10 input, 11 FIFO |
| 84–83 | op: 00 ADD, 01 EXEC, 10 REPLACE, 11 DELETE |
| 82–19 | data (64 bits) |
| 18 | side: 0 buy, 1 sell |
| 17–0 | timestamp in clock cycles |

Data is shown as quantity (top 32 bits) and price (bottom 32) for price
events, as an order ID for order events, and as raw hex for input and FIFO
events.

**Latency rule.** Each event's "Since input" is its timestamp minus the
timestamp of the most recent input event, modulo 2^18. An input event is the
reference and restarts the measurement. Events before the first input event
have no value.

## What gets saved

Everything is under `data/` next to the app (or `--data FOLDER`):

- `state.json` – the queue, configurations and settings.
- `runs/<time>_<configuration>/`
  - `events.csv` – one row per event: decoded fields, latency, and the raw
    payload bytes.
  - `capture.pcap` – every frame sent and received; opens in Wireshark.
  - `run.json` – start time, the configuration, and the queue that was sent.

## Checks

    pip install pytest
    python -m pytest

48 tests: message bytes against the ASX spec examples, frame checksums,
event bit positions, the latency rule, end-to-end runs through the stand-in,
the real capture path on Linux loopback, and the GUI driven without a display.

## Trying it over a cable without the FPGA

`python tools/fake_fpga.py --device <adapter>` runs the stand-in on a real
adapter of a second machine (or loopback on Linux). It is a test aid, not a
model of the RTL: see the note at the top of `obtest/simfpga.py`.

## Layout of the code

| File | Purpose |
|---|---|
| `obtest/itch.py` | ITCH message encoding |
| `obtest/frames.py` | MoldUDP64, UDP, IPv4, Ethernet |
| `obtest/telemetry.py` | event decoding and the latency rule |
| `obtest/pcapio.py` | Npcap / libpcap access through ctypes |
| `obtest/transport.py` | real adapter or stand-in |
| `obtest/engine.py` | connect, send, receive, log (no GUI) |
| `obtest/runlog.py` | run folders, CSV, pcap, latency summary |
| `obtest/model.py` | queue, configurations, settings |
| `obtest/simfpga.py` | the software stand-in |
| `obtest/gui/` | the PySide6 interface |
