"""Start the Order Book Test Interface:  python run.py [--data FOLDER]"""
import sys

from obtest.gui.main_window import main

if __name__ == "__main__":
    sys.exit(main())
