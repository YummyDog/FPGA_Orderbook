"""Render each page to a PNG without a display (development check).

    QT_QPA_PLATFORM=offscreen python tools/screenshots.py <output folder>
"""

import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from PySide6.QtWidgets import QApplication            # noqa: E402

from obtest.gui.main_window import MainWindow          # noqa: E402
from obtest.gui.widgets import QSS                     # noqa: E402


def main() -> None:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "screenshots")
    out.mkdir(parents=True, exist_ok=True)
    app = QApplication([])
    app.setStyle("Fusion")
    app.setStyleSheet(QSS)
    with tempfile.TemporaryDirectory() as data:
        win = MainWindow(Path(data))
        win.resize(1440, 900)
        win.show()
        app.processEvents()
        win.queue_page.fire_queue()
        win.pump()
        win.queue_page.plist.setCurrentRow(1)
        app.processEvents()
        for index, name in enumerate(["queue", "parameters", "connection"]):
            win.tabs.setCurrentIndex(index)
            app.processEvents()
            win.grab().save(str(out / f"{name}.png"))
        # A wider message type, and a smaller window, to check nothing is clipped.
        win.tabs.setCurrentIndex(0)
        page = win.queue_page
        page.f_type.setCurrentIndex(page.f_type.findData("C"))
        app.processEvents()
        win.grab().save(str(out / "queue_executed_with_price.png"))
        win.resize(1280, 760)
        app.processEvents()
        win.grab().save(str(out / "queue_small_window.png"))
        win.close()
    print("saved to", out)


if __name__ == "__main__":
    main()
