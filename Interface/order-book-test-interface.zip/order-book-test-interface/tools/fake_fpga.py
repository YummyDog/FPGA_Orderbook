"""Run the software stand-in FPGA on a real adapter.

Useful for trying the app over a real cable (or loopback on Linux) before the
FPGA is ready:

    python tools/fake_fpga.py --device <adapter> [--telemetry-port 30002]
    python tools/fake_fpga.py --list

It listens for the app's ITCH packets and answers with event packets. It is a
test aid, not a model of the RTL - see obtest/simfpga.py.
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from obtest import pcapio                      # noqa: E402
from obtest.simfpga import SimFpga             # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--device")
    ap.add_argument("--list", action="store_true", help="list adapters and exit")
    ap.add_argument("--telemetry-port", type=int, default=30002)
    ap.add_argument("--reset-port", type=int, default=30003)
    ap.add_argument("--reset-payload", default="5245534554", help="hex bytes")
    args = ap.parse_args()

    if args.list or not args.device:
        for name, desc in pcapio.list_devices():
            print(f"{name}\t{desc}")
        return

    fpga = SimFpga(args.telemetry_port, args.reset_port, bytes.fromhex(args.reset_payload))
    rx = pcapio.Receiver(args.device, f"udp and not dst port {args.telemetry_port}")
    tx = pcapio.Sender(args.device)
    print(f"Stand-in FPGA listening on {args.device}; events go to UDP port "
          f"{args.telemetry_port}. Ctrl+C to stop.", flush=True)
    try:
        while True:
            item = rx.read()
            if item is None:
                continue
            for reply in fpga.handle_frame(item[1]):
                tx.send(reply)
    except KeyboardInterrupt:
        pass
    finally:
        rx.close()
        tx.close()


if __name__ == "__main__":
    main()
