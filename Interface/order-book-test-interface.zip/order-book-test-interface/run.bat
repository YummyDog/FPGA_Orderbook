@echo off
rem Starts the Order Book Test Interface. Run install.bat once first.
cd /d "%~dp0"
py -3 -m obtest %*
if errorlevel 1 pause
