"""Sending and receiving frames: a real adapter, or the software stand-in."""

from __future__ import annotations

import queue
import threading
import time

from . import pcapio
from .model import Settings
from .simfpga import SimFpga


def capture_filter(settings: Settings) -> str:
    """The capture filter for FPGA event packets."""
    text = f"udp and dst port {int(settings.telemetry_port)}"
    extra = settings.extra_filter.strip()
    return f"({text}) and ({extra})" if extra else text


class Transport:
    """Common interface. poll() returns the frames received since the last call."""

    description = ""

    def send(self, frame: bytes) -> None:
        raise NotImplementedError

    def poll(self) -> list[tuple[float, bytes]]:
        raise NotImplementedError

    def stats(self) -> tuple[int, int]:
        """(frames captured, frames dropped by the capture buffer)."""
        return 0, 0

    def error(self) -> str | None:
        return None

    def close(self) -> None:
        pass


class PcapTransport(Transport):
    """Raw frames on a real adapter through Npcap or libpcap.

    Sending and capturing use separate handles, and capturing runs on its own
    thread so a burst from the FPGA is drained while the GUI is busy.
    """

    def __init__(self, device: str, settings: Settings, label: str = ""):
        self.description = label or device
        self._rx = pcapio.Receiver(device, capture_filter(settings))
        try:
            self._tx = pcapio.Sender(device)
        except Exception:
            self._rx.close()
            raise
        self._q: queue.Queue = queue.Queue()
        self._stop = threading.Event()
        self._error: str | None = None
        self._stats = (0, 0)
        self._thread = threading.Thread(target=self._loop, name="capture", daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        last_stats = 0.0
        while not self._stop.is_set():
            try:
                item = self._rx.read()
            except pcapio.PcapError as e:
                self._error = str(e)
                return
            if item is not None:
                self._q.put(item)
            now = time.monotonic()
            if now - last_stats > 0.5:
                self._stats = self._rx.stats()
                last_stats = now

    def send(self, frame: bytes) -> None:
        self._tx.send(frame)

    def poll(self) -> list[tuple[float, bytes]]:
        out = []
        while True:
            try:
                out.append(self._q.get_nowait())
            except queue.Empty:
                return out

    def stats(self) -> tuple[int, int]:
        return self._stats

    def error(self) -> str | None:
        return self._error

    def close(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2)
        self._rx.close()
        self._tx.close()


class SimTransport(Transport):
    """No hardware: frames go to the in-process stand-in and its events come back."""

    description = "Simulated FPGA (no hardware)"

    def __init__(self, settings: Settings):
        try:
            reset_payload = settings.reset_payload()
        except ValueError:
            reset_payload = b""
        self.fpga = SimFpga(settings.telemetry_port, settings.reset_dst_port, reset_payload)
        self._pending: list[tuple[float, bytes]] = []
        self._count = 0

    def send(self, frame: bytes) -> None:
        now = time.time()
        for reply in self.fpga.handle_frame(frame):
            self._pending.append((now, reply))
            self._count += 1

    def poll(self) -> list[tuple[float, bytes]]:
        out, self._pending = self._pending, []
        return out

    def stats(self) -> tuple[int, int]:
        return self._count, 0


def open_transport(settings: Settings, label: str = "") -> Transport:
    from .model import SIM_DEVICE
    if settings.device == SIM_DEVICE:
        return SimTransport(settings)
    return PcapTransport(settings.device, settings, label)
