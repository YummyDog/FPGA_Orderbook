"""Application data: packets, the queue, FPGA configurations and settings."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path

from .frames import Headers, build_mold, build_udp_frame, frame_length, MOLD_HEADER_LEN
from .itch import Message

SIM_DEVICE = "sim"


@dataclass
class Packet:
    """One MoldUDP64 packet and the ITCH messages inside it."""

    session: str = "SESSION001"
    sequence: int = 1
    count: int = 0
    auto: bool = True                    # fill sequence and count automatically
    headers: Headers = field(default_factory=Headers)
    messages: list[Message] = field(default_factory=list)
    status: str = "queued"               # "queued" or "sent"; not saved

    def payload(self) -> bytes:
        return build_mold(self.session, self.sequence, self.count,
                          [m.encode() for m in self.messages])

    def payload_length(self) -> int:
        return MOLD_HEADER_LEN + sum(2 + m.length for m in self.messages)

    def frame_length(self) -> int:
        return frame_length(self.payload_length())

    def type_summary(self) -> str:
        return " · ".join(m.msg_type for m in self.messages) or "empty"

    def to_dict(self) -> dict:
        return {
            "session": self.session, "sequence": self.sequence, "count": self.count,
            "auto": self.auto, "headers": self.headers.to_dict(),
            "messages": [m.to_dict() for m in self.messages],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Packet":
        return cls(
            session=d.get("session", ""), sequence=int(d.get("sequence", 1)),
            count=int(d.get("count", 0)), auto=bool(d.get("auto", True)),
            headers=Headers.from_dict(d.get("headers", {})),
            messages=[Message.from_dict(m) for m in d.get("messages", [])],
        )

    def copy(self) -> "Packet":
        return Packet.from_dict(self.to_dict())


@dataclass
class PacketQueue:
    packets: list[Packet] = field(default_factory=list)
    same_headers: bool = True
    shared_headers: Headers = field(default_factory=Headers)

    def headers_for(self, packet: Packet) -> Headers:
        return self.shared_headers if self.same_headers else packet.headers

    def renumber(self) -> None:
        """Apply the automatic rule to every packet that has it switched on.

        Message count follows the number of messages. Sequence number follows
        on from the previous packet (its sequence plus its count, as MoldUDP64
        defines). The first packet's sequence number is always the user's.
        """
        prev = None
        for p in self.packets:
            if p.auto:
                p.count = len(p.messages)
                if prev is not None:
                    p.sequence = prev.sequence + prev.count
            prev = p

    def build_frame(self, packet: Packet, ip_id: int = 0) -> bytes:
        return build_udp_frame(self.headers_for(packet), packet.payload(), ip_id=ip_id)

    def to_dict(self) -> dict:
        return {"packets": [p.to_dict() for p in self.packets],
                "same_headers": self.same_headers,
                "shared_headers": self.shared_headers.to_dict()}

    @classmethod
    def from_dict(cls, d: dict) -> "PacketQueue":
        return cls(packets=[Packet.from_dict(p) for p in d.get("packets", [])],
                   same_headers=bool(d.get("same_headers", True)),
                   shared_headers=Headers.from_dict(d.get("shared_headers", {})))


@dataclass
class FpgaConfig:
    """A description of one FPGA build.

    Nothing here is sent to the FPGA. The clock frequency converts cycle
    counts to nanoseconds; everything else is a label stored with each run so
    that latency can be compared between builds.
    """

    name: str = "Baseline"
    num_tables: int = 4
    addr_bits: int = 12
    hash_function: str = "XOR mask (hash65)"
    clock_mhz: float = 156.25
    other: list[list[str]] = field(default_factory=list)   # [[name, value], ...]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "FpgaConfig":
        return cls(name=str(d.get("name", "Baseline")),
                   num_tables=int(d.get("num_tables", 4)),
                   addr_bits=int(d.get("addr_bits", 12)),
                   hash_function=str(d.get("hash_function", "XOR mask (hash65)")),
                   clock_mhz=float(d.get("clock_mhz", 156.25)),
                   other=[[str(a), str(b)] for a, b in d.get("other", [])])

    def copy(self) -> "FpgaConfig":
        return FpgaConfig.from_dict(self.to_dict())


@dataclass
class Settings:
    device: str = SIM_DEVICE              # SIM_DEVICE or a capture device name
    telemetry_port: int = 30002           # UDP destination port of FPGA events
    extra_filter: str = ""                # optional extra capture filter
    packet_gap_ms: int = 0                # pause between packets when firing the queue
    reset_first: bool = False
    reset_dst_port: int = 30003
    reset_payload_hex: str = "52 45 53 45 54"

    def reset_payload(self) -> bytes:
        text = self.reset_payload_hex.replace(",", " ").replace("0x", "").replace(":", " ")
        try:
            return bytes.fromhex("".join(text.split()))
        except ValueError:
            raise ValueError("Reset payload must be hex bytes, e.g. 52 45 53 45 54") from None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Settings":
        s = cls()
        for k, v in d.items():
            if hasattr(s, k):
                setattr(s, k, type(getattr(s, k))(v))
        return s


def sample_queue() -> PacketQueue:
    """The 'new order entered, amended and deleted' example from the ASX spec."""
    oid, book = 0x62018A81000119DD, 70578
    add = Message("A", 251202700, oid, book, "B", 1, 100, 55000, 0, 2)
    delete = Message("D", 29312500, oid, book, "B")
    add2 = Message("A", 29312500, oid, book, "B", 1, 90, 55100, 0, 2)
    delete2 = Message("D", 128252200, oid, book, "B")
    q = PacketQueue(packets=[Packet(messages=[add]), Packet(messages=[delete, add2]),
                             Packet(messages=[delete2])])
    q.renumber()
    return q


@dataclass
class AppState:
    queue: PacketQueue = field(default_factory=sample_queue)
    configs: list[FpgaConfig] = field(default_factory=lambda: [FpgaConfig()])
    active_config: int = 0
    settings: Settings = field(default_factory=Settings)

    @property
    def config(self) -> FpgaConfig:
        self.active_config = max(0, min(self.active_config, len(self.configs) - 1))
        return self.configs[self.active_config]

    def to_dict(self) -> dict:
        return {"queue": self.queue.to_dict(),
                "configs": [c.to_dict() for c in self.configs],
                "active_config": self.active_config,
                "settings": self.settings.to_dict()}

    @classmethod
    def from_dict(cls, d: dict) -> "AppState":
        configs = [FpgaConfig.from_dict(c) for c in d.get("configs", [])] or [FpgaConfig()]
        queue = PacketQueue.from_dict(d["queue"]) if "queue" in d else sample_queue()
        return cls(queue=queue, configs=configs,
                   active_config=int(d.get("active_config", 0)),
                   settings=Settings.from_dict(d.get("settings", {})))

    def save(self, data_dir: Path) -> None:
        data_dir.mkdir(parents=True, exist_ok=True)
        tmp = data_dir / "state.json.tmp"
        tmp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        os.replace(tmp, data_dir / "state.json")

    @classmethod
    def load(cls, data_dir: Path) -> "AppState":
        path = data_dir / "state.json"
        if not path.exists():
            return cls()
        try:
            return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (ValueError, KeyError, TypeError):
            # Keep the unreadable file for the user and start clean.
            os.replace(path, data_dir / "state.json.bad")
            return cls()
