"""Order book test interface: ITCH packet sender and FPGA event logger."""

__version__ = "0.1.0"
