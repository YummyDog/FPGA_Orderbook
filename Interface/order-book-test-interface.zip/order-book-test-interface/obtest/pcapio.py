"""Thin ctypes wrapper around libpcap (Linux) and Npcap's wpcap.dll (Windows).

Only what the app needs: list the adapters, send a raw frame, and capture
frames with a filter. No third-party Python packages are required; on Windows
Npcap must be installed (https://npcap.com).
"""

from __future__ import annotations

import ctypes
import ctypes.util
import os
import sys
from ctypes import (POINTER, Structure, byref, c_char_p, c_int, c_long, c_ubyte, c_uint,
                    c_void_p)

PCAP_ERRBUF_SIZE = 256
PCAP_D_IN = 1
DLT_EN10MB = 1


class PcapError(RuntimeError):
    pass


class _Timeval(Structure):
    _fields_ = [("tv_sec", c_long), ("tv_usec", c_long)]


class _PktHdr(Structure):
    _fields_ = [("ts", _Timeval), ("caplen", c_uint), ("len", c_uint)]


class _PcapIf(Structure):
    pass


_PcapIf._fields_ = [("next", POINTER(_PcapIf)), ("name", c_char_p),
                    ("description", c_char_p), ("addresses", c_void_p), ("flags", c_uint)]


class _BpfProgram(Structure):
    _fields_ = [("bf_len", c_uint), ("bf_insns", c_void_p)]


class _PcapStat(Structure):
    # Padded: some Windows builds append extra counters.
    _fields_ = [("ps_recv", c_uint), ("ps_drop", c_uint), ("ps_ifdrop", c_uint),
                ("pad", c_uint * 5)]


_lib = None


def _load():
    """Load the pcap library once, with a clear message if it is missing."""
    global _lib
    if _lib is not None:
        return _lib
    lib = None
    if sys.platform == "win32":
        root = os.environ.get("SystemRoot", r"C:\Windows")
        for folder in (os.path.join(root, "System32", "Npcap"), os.path.join(root, "System32")):
            path = os.path.join(folder, "wpcap.dll")
            if os.path.exists(path):
                os.add_dll_directory(folder)
                lib = ctypes.CDLL(path)
                break
        if lib is None:
            raise PcapError("Npcap was not found. Install it from https://npcap.com "
                            "and restart the app.")
    else:
        for name in (ctypes.util.find_library("pcap"), "libpcap.so.1", "libpcap.so.0.8",
                     "libpcap.dylib"):
            if not name:
                continue
            try:
                lib = ctypes.CDLL(name)
                break
            except OSError:
                continue
        if lib is None:
            raise PcapError("libpcap was not found. Install the libpcap package.")

    def sig(name, restype, *argtypes):
        fn = getattr(lib, name)
        fn.restype, fn.argtypes = restype, list(argtypes)

    sig("pcap_findalldevs", c_int, POINTER(POINTER(_PcapIf)), c_char_p)
    sig("pcap_freealldevs", None, POINTER(_PcapIf))
    sig("pcap_open_live", c_void_p, c_char_p, c_int, c_int, c_int, c_char_p)
    sig("pcap_create", c_void_p, c_char_p, c_char_p)
    sig("pcap_set_snaplen", c_int, c_void_p, c_int)
    sig("pcap_set_promisc", c_int, c_void_p, c_int)
    sig("pcap_set_timeout", c_int, c_void_p, c_int)
    sig("pcap_set_buffer_size", c_int, c_void_p, c_int)
    sig("pcap_activate", c_int, c_void_p)
    sig("pcap_close", None, c_void_p)
    sig("pcap_sendpacket", c_int, c_void_p, POINTER(c_ubyte), c_int)
    sig("pcap_next_ex", c_int, c_void_p, POINTER(POINTER(_PktHdr)), POINTER(POINTER(c_ubyte)))
    sig("pcap_compile", c_int, c_void_p, POINTER(_BpfProgram), c_char_p, c_int, c_uint)
    sig("pcap_setfilter", c_int, c_void_p, POINTER(_BpfProgram))
    sig("pcap_freecode", None, POINTER(_BpfProgram))
    sig("pcap_geterr", c_char_p, c_void_p)
    sig("pcap_setdirection", c_int, c_void_p, c_int)
    sig("pcap_stats", c_int, c_void_p, POINTER(_PcapStat))
    sig("pcap_datalink", c_int, c_void_p)
    _lib = lib
    return lib


def _text(raw) -> str:
    return raw.decode("utf-8", errors="replace") if raw else ""


def list_devices() -> list[tuple[str, str]]:
    """Return [(device name, description)] for every capture device."""
    lib = _load()
    head = POINTER(_PcapIf)()
    err = ctypes.create_string_buffer(PCAP_ERRBUF_SIZE)
    if lib.pcap_findalldevs(byref(head), err) != 0:
        raise PcapError(f"Could not list adapters: {_text(err.value)}")
    out = []
    node = head
    while node:
        dev = node.contents
        out.append((_text(dev.name), _text(dev.description)))
        node = dev.next
    if head:
        lib.pcap_freealldevs(head)
    return out


class Sender:
    """Sends complete Ethernet frames (without FCS) on one adapter."""

    def __init__(self, device: str):
        self._lib = _load()
        err = ctypes.create_string_buffer(PCAP_ERRBUF_SIZE)
        self._h = self._lib.pcap_open_live(device.encode(), 64, 0, 1, err)
        if not self._h:
            raise PcapError(f"Could not open {device} for sending: {_text(err.value)}")

    def send(self, frame: bytes) -> None:
        buf = (c_ubyte * len(frame)).from_buffer_copy(frame)
        if self._lib.pcap_sendpacket(self._h, buf, len(frame)) != 0:
            raise PcapError(f"Send failed: {_text(self._lib.pcap_geterr(self._h))}")

    def close(self) -> None:
        if self._h:
            self._lib.pcap_close(self._h)
            self._h = None


class Receiver:
    """Captures frames matching a filter. Call read() repeatedly from one thread."""

    def __init__(self, device: str, bpf_filter: str = "", buffer_bytes: int = 32 << 20,
                 timeout_ms: int = 20):
        self._lib = lib = _load()
        err = ctypes.create_string_buffer(PCAP_ERRBUF_SIZE)
        self._h = lib.pcap_create(device.encode(), err)
        if not self._h:
            raise PcapError(f"Could not open {device}: {_text(err.value)}")
        lib.pcap_set_snaplen(self._h, 65535)
        lib.pcap_set_promisc(self._h, 1)
        lib.pcap_set_timeout(self._h, timeout_ms)
        lib.pcap_set_buffer_size(self._h, buffer_bytes)     # room for bursts
        rc = lib.pcap_activate(self._h)
        if rc < 0:
            msg = _text(lib.pcap_geterr(self._h))
            lib.pcap_close(self._h)
            self._h = None
            raise PcapError(f"Could not start capturing on {device}: {msg or rc}")
        if lib.pcap_datalink(self._h) != DLT_EN10MB:
            self.close()
            raise PcapError(f"{device} is not an Ethernet adapter")
        lib.pcap_setdirection(self._h, PCAP_D_IN)            # best effort
        if bpf_filter:
            prog = _BpfProgram()
            if lib.pcap_compile(self._h, byref(prog), bpf_filter.encode(), 1, 0xFFFFFFFF) != 0:
                msg = _text(lib.pcap_geterr(self._h))
                self.close()
                raise PcapError(f"Capture filter {bpf_filter!r} is not valid: {msg}")
            lib.pcap_setfilter(self._h, byref(prog))
            lib.pcap_freecode(byref(prog))

    def read(self) -> tuple[float, bytes] | None:
        """Return (host time, frame bytes), or None if nothing arrived in the timeout."""
        hdr = POINTER(_PktHdr)()
        data = POINTER(c_ubyte)()
        rc = self._lib.pcap_next_ex(self._h, byref(hdr), byref(data))
        if rc == 1:
            h = hdr.contents
            return (h.ts.tv_sec + h.ts.tv_usec / 1_000_000,
                    ctypes.string_at(data, h.caplen))
        if rc == 0:
            return None
        raise PcapError(f"Capture failed: {_text(self._lib.pcap_geterr(self._h))}")

    def stats(self) -> tuple[int, int]:
        """(frames received by the filter, frames dropped because the buffer was full)."""
        st = _PcapStat()
        if self._h and self._lib.pcap_stats(self._h, byref(st)) == 0:
            return st.ps_recv, st.ps_drop + st.ps_ifdrop
        return 0, 0

    def close(self) -> None:
        if self._h:
            self._lib.pcap_close(self._h)
            self._h = None
