"""Run storage: the event log, a capture file and what was sent.

Each run gets its own folder under <data>/runs/ containing

    run.json      when it started, the FPGA configuration and the queue sent
    events.csv    one row per FPGA event, decoded, with the raw payload bytes
    capture.pcap  every frame sent and received, openable in Wireshark
"""

from __future__ import annotations

import csv
import json
import re
import statistics
import struct
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .frames import UdpFrame, format_ip
from .model import FpgaConfig
from .telemetry import Event, LatencyTracker, cycles_to_ns, decode_event, INPUT

CSV_COLUMNS = ["index", "host_time", "event", "op", "side", "data_hex", "data_decoded",
               "timestamp_cycles", "since_input_cycles", "since_input_ns",
               "raw_payload_hex", "source"]


@dataclass
class LogRow:
    index: int
    host_time: float
    event: str               # Price / Order / Input / FIFO / Malformed
    op: str
    side: str
    data_hex: str
    data_decoded: str
    ts: int | None
    since_cycles: int | None
    since_ns: float | None
    raw_hex: str
    source: str
    is_reference: bool = False

    def csv_row(self) -> list:
        return [self.index,
                datetime.fromtimestamp(self.host_time).isoformat(timespec="microseconds"),
                self.event, self.op, self.side, self.data_hex, self.data_decoded,
                "" if self.ts is None else self.ts,
                "" if self.since_cycles is None else self.since_cycles,
                "" if self.since_ns is None else f"{self.since_ns:.3f}",
                self.raw_hex, self.source]


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-") or "config"


class Run:
    """One test run. Files are written as events arrive, so nothing is lost on a crash."""

    def __init__(self, data_dir: Path, config: FpgaConfig, queue_snapshot: dict | None = None):
        self.config = config.copy()
        self.started = time.time()
        stamp = datetime.fromtimestamp(self.started).strftime("%Y%m%d-%H%M%S")
        base = data_dir / "runs"
        base.mkdir(parents=True, exist_ok=True)
        name, n = f"{stamp}_{_slug(config.name)}", 1
        while (base / name).exists():
            n += 1
            name = f"{stamp}-{n}_{_slug(config.name)}"
        self.dir = base / name
        self.dir.mkdir()
        self.name = name
        self.rows: list[LogRow] = []
        self.sent_frames = 0
        self.tracker = LatencyTracker()

        (self.dir / "run.json").write_text(json.dumps({
            "started": datetime.fromtimestamp(self.started).isoformat(timespec="seconds"),
            "config": self.config.to_dict(),
            "queue": queue_snapshot or {},
        }, indent=2), encoding="utf-8")

        self._csv_file = open(self.dir / "events.csv", "w", newline="", encoding="utf-8")
        self._csv = csv.writer(self._csv_file)
        self._csv.writerow(CSV_COLUMNS)
        self._pcap = open(self.dir / "capture.pcap", "wb")
        self._pcap.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))

    # ------------------------------------------------------------ recording
    def _pcap_record(self, host_time: float, frame: bytes) -> None:
        sec = int(host_time)
        usec = int((host_time - sec) * 1_000_000)
        self._pcap.write(struct.pack("<IIII", sec, usec, len(frame), len(frame)) + frame)

    def add_sent(self, frame: bytes, host_time: float | None = None) -> None:
        self._pcap_record(host_time or time.time(), frame)
        self.sent_frames += 1

    def add_received(self, host_time: float, frame: bytes, udp: UdpFrame) -> LogRow:
        """Decode one FPGA event frame, apply the latency rule and log it."""
        self._pcap_record(host_time, frame)
        source = f"{format_ip(udp.src_ip)}:{udp.src_port}"
        index = len(self.rows) + 1
        try:
            ev: Event = decode_event(udp.payload)
        except ValueError:
            row = LogRow(index, host_time, "Malformed", "", "", "",
                         f"{len(udp.payload)} byte payload", None, None, None,
                         udp.payload.hex(), source)
        else:
            cycles = self.tracker.update(ev)
            row = LogRow(index, host_time, ev.type_name, ev.op_name, ev.side_name,
                         f"{ev.data:016x}", ev.describe_data(), ev.ts, cycles,
                         cycles_to_ns(cycles, self.config.clock_mhz),
                         ev.raw.hex(), source, is_reference=(ev.etype == INPUT))
        self.rows.append(row)
        self._csv.writerow(row.csv_row())
        return row

    def flush(self) -> None:
        if not self._csv_file.closed:
            self._csv_file.flush()
            self._pcap.flush()

    def close(self) -> None:
        if not self._csv_file.closed:
            self._csv_file.close()
            self._pcap.close()


# ------------------------------------------------------------------ statistics

def export_rows(rows: list[LogRow], path: Path) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(CSV_COLUMNS)
        for r in rows:
            w.writerow(r.csv_row())


def latency_by_config(data_dir: Path, event: str = "All") -> list[dict]:
    """Summarise saved runs: latency since input, grouped by configuration name.

    `event` is "All", "Price", "Order" or "FIFO". Input events are the
    reference and never counted. Returns rows sorted by configuration name.
    """
    groups: dict[str, dict] = {}
    base = data_dir / "runs"
    if not base.exists():
        return []
    for run_dir in sorted(base.iterdir()):
        meta_path, csv_path = run_dir / "run.json", run_dir / "events.csv"
        if not (meta_path.exists() and csv_path.exists()):
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            name = meta["config"]["name"]
        except (ValueError, KeyError, TypeError):
            continue
        values = []
        with open(csv_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("event") in ("Input", "Malformed") or not row.get("since_input_ns"):
                    continue
                if event != "All" and row.get("event") != event:
                    continue
                try:
                    values.append(float(row["since_input_ns"]))
                except ValueError:
                    continue
        g = groups.setdefault(name, {"config": name, "runs": 0, "values": []})
        if values:
            g["runs"] += 1
            g["values"].extend(values)
    out = []
    for name in sorted(groups):
        v = groups[name]["values"]
        out.append({"config": name, "runs": groups[name]["runs"], "events": len(v),
                    "median_ns": statistics.median(v) if v else None,
                    "worst_ns": max(v) if v else None})
    return out
