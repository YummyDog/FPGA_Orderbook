"""A software stand-in for the FPGA.

It consumes the ITCH packets the app sends and answers with event packets in
the agreed 87-bit format, so the whole app can be exercised with no hardware.

THIS IS NOT THE RTL. Which events it emits for each message, what it puts in
the data field of input and FIFO events (the MoldUDP64 sequence number of the
message), and every latency it reports are assumptions made for testing the
app. Its numbers say nothing about the real design.
"""

from __future__ import annotations

import random

from . import itch
from .frames import Headers, build_udp_frame, parse_mold, parse_udp_frame
from .telemetry import PRICE, ORDER, INPUT, FIFO, TS_MOD, encode_event

OP_ADD, OP_EXEC, OP_REPLACE, OP_DELETE = 0, 1, 2, 3


class SimFpga:
    def __init__(self, telemetry_port: int = 30002, reset_port: int = 30003,
                 reset_payload: bytes = b"RESET", seed: int = 1):
        self.telemetry_port = telemetry_port
        self.reset_port = reset_port
        self.reset_payload = reset_payload
        self.headers = Headers(dst_mac="ff:ff:ff:ff:ff:ff", src_mac="02:00:00:00:00:fe",
                               dst_ip="255.255.255.255", src_ip="192.168.1.20",
                               dst_port=telemetry_port, src_port=telemetry_port)
        self._rng = random.Random(seed)
        self.cycle = 1000
        self.resets = 0
        self.orders: dict[tuple[int, int], list[int]] = {}    # (side, id) -> [qty, price]
        self.levels: dict[tuple[int, int], int] = {}          # (side, price) -> qty

    def reset(self) -> None:
        self.orders.clear()
        self.levels.clear()
        self.resets += 1

    # ---------------------------------------------------------------- input
    def handle_frame(self, frame: bytes) -> list[bytes]:
        """Process one frame from the app and return the event frames to send back."""
        udp = parse_udp_frame(frame)
        if udp is None:
            return []
        if udp.dst_port == self.reset_port and udp.payload == self.reset_payload:
            self.reset()
            return []
        if udp.dst_port in (self.telemetry_port, self.reset_port):
            return []
        try:
            _, sequence, _, messages = parse_mold(udp.payload)
        except ValueError:
            return []
        out: list[bytes] = []
        for i, raw in enumerate(messages):
            try:
                msg = itch.decode(raw)
            except ValueError:
                continue
            for payload in self._events_for(msg, sequence + i):
                out.append(build_udp_frame(self.headers, payload))
        return out

    # --------------------------------------------------------------- events
    def _level(self, side: int, price: int, delta: int) -> int:
        total = (self.levels.get((side, price), 0) + delta) & 0xFFFFFFFF
        self.levels[(side, price)] = total
        return total

    def _events_for(self, msg: itch.Message, seq: int) -> list[bytes]:
        t0 = self.cycle
        self.cycle = (self.cycle + self._rng.randint(20, 40)) % TS_MOD
        t_fifo = t0 + 3
        t_order = t_fifo + self._rng.randint(4, 9)
        t_price = t_order + self._rng.randint(3, 5)
        ev = [encode_event(INPUT, 0, seq, 0, t0), encode_event(FIFO, 0, seq, 0, t_fifo)]
        if msg.msg_type == "T":
            return ev

        side = 0 if msg.side == "B" else 1
        key = (side, msg.order_id)
        oid = msg.order_id

        def price_event(op: int, qty: int, price: int, ts: int) -> bytes:
            return encode_event(PRICE, op, ((qty & 0xFFFFFFFF) << 32) | (price & 0xFFFFFFFF),
                                side, ts)

        if msg.msg_type in ("A", "F"):
            self.orders[key] = [msg.quantity, msg.price]
            ev.append(encode_event(ORDER, OP_ADD, oid, side, t_order))
            ev.append(price_event(OP_ADD, self._level(side, msg.price, msg.quantity),
                                  msg.price, t_price))
        elif msg.msg_type == "D":
            ev.append(encode_event(ORDER, OP_DELETE, oid, side, t_order))
            if key in self.orders:
                qty, price = self.orders.pop(key)
                ev.append(price_event(OP_DELETE, self._level(side, price, -qty), price, t_price))
        elif msg.msg_type in ("E", "C"):
            ev.append(encode_event(ORDER, OP_EXEC, oid, side, t_order))
            if key in self.orders:
                order = self.orders[key]
                done = min(order[0], msg.quantity)
                order[0] -= done
                ev.append(price_event(OP_DELETE, self._level(side, order[1], -done),
                                      order[1], t_price))
                if order[0] == 0:
                    del self.orders[key]
        elif msg.msg_type == "U":
            ev.append(encode_event(ORDER, OP_REPLACE, oid, side, t_order))
            old = self.orders.get(key)
            self.orders[key] = [msg.quantity, msg.price]
            if old and old[1] == msg.price:
                total = self._level(side, msg.price, msg.quantity - old[0])
                ev.append(price_event(OP_REPLACE, total, msg.price, t_price))
            else:
                if old:
                    ev.append(price_event(OP_DELETE, self._level(side, old[1], -old[0]),
                                          old[1], t_price))
                ev.append(price_event(OP_ADD, self._level(side, msg.price, msg.quantity),
                                      msg.price, t_price + 2))
        return ev
