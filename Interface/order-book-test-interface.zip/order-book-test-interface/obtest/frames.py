"""MoldUDP64, UDP, IPv4 and Ethernet framing.

The app builds the whole frame itself (Ethernet header onwards) so that every
header field can be set from the GUI. The NIC appends the FCS.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, asdict, fields

MOLD_HEADER_LEN = 20
ETH_HEADER_LEN = 14
IPV4_HEADER_LEN = 20
UDP_HEADER_LEN = 8
MIN_FRAME_LEN = 60          # without FCS


# ----------------------------------------------------------------- addresses

def parse_mac(text: str) -> bytes:
    t = text.strip().lower().replace("-", ":")
    parts = t.split(":")
    if len(parts) != 6:
        raise ValueError(f"MAC address {text!r} must look like 02:00:00:00:00:01")
    try:
        raw = bytes(int(p, 16) for p in parts)
    except ValueError:
        raise ValueError(f"MAC address {text!r} is not valid hex") from None
    return raw


def format_mac(raw: bytes) -> str:
    return ":".join(f"{b:02x}" for b in raw)


def parse_ip(text: str) -> bytes:
    parts = text.strip().split(".")
    if len(parts) != 4:
        raise ValueError(f"IP address {text!r} must look like 192.168.1.10")
    try:
        values = [int(p) for p in parts]
    except ValueError:
        raise ValueError(f"IP address {text!r} is not valid") from None
    if any(not 0 <= v <= 255 for v in values):
        raise ValueError(f"IP address {text!r} is not valid")
    return bytes(values)


def format_ip(raw: bytes) -> str:
    return ".".join(str(b) for b in raw)


def parse_port(value) -> int:
    try:
        port = int(str(value).strip())
    except ValueError:
        raise ValueError(f"Port {value!r} must be a number") from None
    if not 0 <= port <= 65535:
        raise ValueError("Port must be between 0 and 65535")
    return port


@dataclass
class Headers:
    """The Ethernet, IPv4 and UDP header fields the user can set."""

    dst_mac: str = "ff:ff:ff:ff:ff:ff"
    src_mac: str = "02:00:00:00:00:01"
    dst_ip: str = "192.168.1.20"
    src_ip: str = "192.168.1.10"
    dst_port: int = 30001
    src_port: int = 30000

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Headers":
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})


# ------------------------------------------------------------------- MoldUDP64

def build_mold(session: str, sequence: int, count: int, messages: list[bytes]) -> bytes:
    """MoldUDP64 downstream packet.

    `count` is written to the header exactly as given, so it can deliberately
    disagree with the number of message blocks that follow.
    """
    raw_session = session.encode("ascii", errors="strict")
    if len(raw_session) > 10:
        raise ValueError("Session must be at most 10 characters")
    if not 0 <= sequence <= 0xFFFFFFFFFFFFFFFF:
        raise ValueError("Sequence number does not fit in 8 bytes")
    if not 0 <= count <= 0xFFFF:
        raise ValueError("Message count must be between 0 and 65535")
    out = bytearray(struct.pack(">10sQH", raw_session.ljust(10, b" "), sequence, count))
    for m in messages:
        if len(m) > 0xFFFF:
            raise ValueError("Message too long")
        out += struct.pack(">H", len(m)) + m
    return bytes(out)


def parse_mold(payload: bytes):
    """Return (session, sequence, count, [message bytes]). Used by the stand-in."""
    if len(payload) < MOLD_HEADER_LEN:
        raise ValueError("Payload shorter than a MoldUDP64 header")
    session, sequence, count = struct.unpack(">10sQH", payload[:MOLD_HEADER_LEN])
    messages, pos = [], MOLD_HEADER_LEN
    if count != 0xFFFF:
        for _ in range(count):
            if pos + 2 > len(payload):
                break
            (length,) = struct.unpack(">H", payload[pos:pos + 2])
            pos += 2
            messages.append(payload[pos:pos + length])
            pos += length
    return session.decode("ascii", errors="replace").rstrip(), sequence, count, messages


# --------------------------------------------------------------- UDP/IP/Ethernet

def _checksum(data: bytes) -> int:
    if len(data) % 2:
        data += b"\x00"
    total = sum(struct.unpack(f">{len(data) // 2}H", data))
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def build_udp_frame(headers: Headers, payload: bytes, ip_id: int = 0, ttl: int = 64,
                    pad: bool = True) -> bytes:
    """Ethernet II + IPv4 + UDP frame, without FCS.

    Frames shorter than the 60-byte Ethernet minimum are padded with zeros
    after the UDP payload; the IP and UDP length fields still give the real
    payload length.
    """
    dst_mac, src_mac = parse_mac(headers.dst_mac), parse_mac(headers.src_mac)
    dst_ip, src_ip = parse_ip(headers.dst_ip), parse_ip(headers.src_ip)
    dst_port, src_port = parse_port(headers.dst_port), parse_port(headers.src_port)

    udp_len = UDP_HEADER_LEN + len(payload)
    total_len = IPV4_HEADER_LEN + udp_len
    if total_len > 0xFFFF:
        raise ValueError("Packet is too large for IPv4")

    ip = struct.pack(">BBHHHBBH4s4s", 0x45, 0, total_len, ip_id & 0xFFFF, 0x4000,
                     ttl, 17, 0, src_ip, dst_ip)
    ip = ip[:10] + struct.pack(">H", _checksum(ip)) + ip[12:]

    udp = struct.pack(">HHHH", src_port, dst_port, udp_len, 0)
    pseudo = src_ip + dst_ip + struct.pack(">BBH", 0, 17, udp_len)
    csum = _checksum(pseudo + udp + payload) or 0xFFFF
    udp = udp[:6] + struct.pack(">H", csum)

    frame = dst_mac + src_mac + b"\x08\x00" + ip + udp + payload
    if pad and len(frame) < MIN_FRAME_LEN:
        frame += b"\x00" * (MIN_FRAME_LEN - len(frame))
    return frame


def frame_length(payload_len: int) -> int:
    """Frame length without FCS for a UDP payload of the given size."""
    return max(MIN_FRAME_LEN, ETH_HEADER_LEN + IPV4_HEADER_LEN + UDP_HEADER_LEN + payload_len)


@dataclass
class UdpFrame:
    dst_mac: bytes
    src_mac: bytes
    src_ip: bytes
    dst_ip: bytes
    src_port: int
    dst_port: int
    payload: bytes


def parse_udp_frame(frame: bytes) -> UdpFrame | None:
    """Parse an Ethernet frame carrying IPv4/UDP. Returns None for anything else.

    The payload is cut to the UDP length field, so Ethernet padding is dropped.
    """
    if len(frame) < ETH_HEADER_LEN + IPV4_HEADER_LEN + UDP_HEADER_LEN:
        return None
    dst_mac, src_mac = frame[0:6], frame[6:12]
    (ethertype,) = struct.unpack(">H", frame[12:14])
    pos = 14
    if ethertype == 0x8100:                      # one 802.1Q tag
        (ethertype,) = struct.unpack(">H", frame[16:18])
        pos = 18
    if ethertype != 0x0800:
        return None
    if frame[pos] >> 4 != 4:
        return None
    ihl = (frame[pos] & 0x0F) * 4
    if ihl < 20 or frame[pos + 9] != 17:
        return None
    src_ip, dst_ip = frame[pos + 12:pos + 16], frame[pos + 16:pos + 20]
    upos = pos + ihl
    if len(frame) < upos + UDP_HEADER_LEN:
        return None
    src_port, dst_port, udp_len, _ = struct.unpack(">HHHH", frame[upos:upos + 8])
    if udp_len < UDP_HEADER_LEN:
        return None
    payload = frame[upos + 8:upos + udp_len]
    return UdpFrame(dst_mac, src_mac, src_ip, dst_ip, src_port, dst_port, payload)
