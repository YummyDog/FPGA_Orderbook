"""The app's logic without any GUI: connect, send the queue, log what comes back."""

from __future__ import annotations

import time
from pathlib import Path

from .frames import build_udp_frame, parse_udp_frame, Headers
from .model import AppState
from .runlog import LogRow, Run
from .transport import Transport, open_transport


class Engine:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.state = AppState.load(self.data_dir)
        self.state.queue.renumber()
        self.transport: Transport | None = None
        self.run: Run | None = None
        self._ip_id = 0

    # ----------------------------------------------------------- connection
    @property
    def connected(self) -> bool:
        return self.transport is not None

    def connect(self, label: str = "") -> None:
        self.disconnect()
        self.transport = open_transport(self.state.settings, label)

    def disconnect(self) -> None:
        if self.transport is not None:
            self.transport.close()
            self.transport = None
        self.end_run()

    def save(self) -> None:
        self.state.save(self.data_dir)

    # ----------------------------------------------------------------- runs
    def new_run(self) -> Run:
        self.end_run()
        self.run = Run(self.data_dir, self.state.config, self.state.queue.to_dict())
        return self.run

    def end_run(self) -> None:
        if self.run is not None:
            self.run.close()
            self.run = None

    def _ensure_run(self) -> Run:
        return self.run if self.run is not None else self.new_run()

    # -------------------------------------------------------------- sending
    def _send(self, frame: bytes) -> None:
        if self.transport is None:
            raise RuntimeError("Not connected. Connect on the Connection page first.")
        run = self._ensure_run()
        self.transport.send(frame)
        run.add_sent(frame)

    def send_reset(self) -> None:
        """Send the reset packet: the configured payload to the reset port."""
        s = self.state.settings
        shared = self.state.queue.shared_headers
        headers = Headers(shared.dst_mac, shared.src_mac, shared.dst_ip, shared.src_ip,
                          s.reset_dst_port, shared.src_port)
        self._ip_id += 1
        self._send(build_udp_frame(headers, s.reset_payload(), ip_id=self._ip_id))
        if self.run is not None:
            self.run.tracker.reset()

    def send_packet(self, index: int) -> None:
        packet = self.state.queue.packets[index]
        self._ip_id += 1
        self._send(self.state.queue.build_frame(packet, ip_id=self._ip_id))
        packet.status = "sent"

    def rearm(self) -> None:
        for p in self.state.queue.packets:
            p.status = "queued"

    def next_queued(self) -> int | None:
        for i, p in enumerate(self.state.queue.packets):
            if p.status == "queued":
                return i
        return None

    def validate_queue(self) -> None:
        """Raise ValueError naming the first packet that cannot be built."""
        q = self.state.queue
        for i, p in enumerate(q.packets):
            try:
                q.build_frame(p)
            except ValueError as e:
                raise ValueError(f"Packet {i + 1}: {e}") from None

    def fire_all(self) -> int:
        """Start a new run and send every packet in order, with the configured gap."""
        self.validate_queue()
        s = self.state.settings
        self.new_run()
        self.rearm()
        if s.reset_first:
            self.send_reset()
        for i in range(len(self.state.queue.packets)):
            if i and s.packet_gap_ms > 0:
                time.sleep(s.packet_gap_ms / 1000.0)
            self.send_packet(i)
        return len(self.state.queue.packets)

    def fire_next(self) -> int | None:
        """Send the next queued packet. Starts a new run when the queue restarts."""
        if not self.state.queue.packets:
            return None
        index = self.next_queued()
        if index is None or index == 0 or self.run is None:
            if index is None:
                self.rearm()
                index = 0
            self.validate_queue()
            self.new_run()
            if self.state.settings.reset_first:
                self.send_reset()
        self.send_packet(index)
        return index

    # ------------------------------------------------------------ receiving
    def pump(self) -> list[LogRow]:
        """Collect frames received since the last call and log the FPGA events."""
        if self.transport is None:
            return []
        rows = []
        port = self.state.settings.telemetry_port
        for host_time, frame in self.transport.poll():
            udp = parse_udp_frame(frame)
            if udp is None or udp.dst_port != port:
                continue
            rows.append(self._ensure_run().add_received(host_time, frame, udp))
        if rows and self.run is not None:
            self.run.flush()
        return rows
