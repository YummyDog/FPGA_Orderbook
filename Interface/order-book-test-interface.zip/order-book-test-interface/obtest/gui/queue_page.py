"""Packet queue page: build packets, fire them, read the event and latency log."""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QFileDialog,
                               QFormLayout, QFrame, QHBoxLayout, QHeaderView, QListWidget,
                               QMessageBox, QScrollArea, QSplitter, QTableView, QTableWidget,
                               QTableWidgetItem, QWidget)

from .. import itch
from ..engine import Engine
from ..frames import format_ip, format_mac, parse_ip, parse_mac, parse_port
from ..itch import I32_MAX, I32_MIN, MSG_TYPES, U8, U16, U32, U64, Message
from ..model import Packet
from ..runlog import export_rows
from .logmodel import LogModel
from .widgets import (TextField, button, grid, h2, label, labelled, mono_font, muted, panel,
                      parse_int, row, set_chip)

MESSAGE_COLUMNS = ["Seq", "Type", "Order ID", "Book", "Side", "Qty", "Price"]
LOG_WIDTHS = [44, 58, 72, 48, 180, 84, 156]


def _session(text: str) -> str:
    t = text.strip()
    try:
        t.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError("Session must be plain ASCII") from None
    if len(t) > 10:
        raise ValueError("Session must be at most 10 characters")
    return t


def _alpha7(name: str):
    def parse(text: str) -> str:
        t = text.strip()
        if len(t) > 7:
            raise ValueError(f"{name} must be at most 7 characters")
        try:
            t.encode("latin-1")
        except UnicodeEncodeError:
            raise ValueError(f"{name} has characters that cannot be sent") from None
        return t
    return parse


class QueuePage(QWidget):
    changed = Signal()            # something worth saving was edited

    def __init__(self, engine: Engine, notify):
        super().__init__()
        self.setObjectName("page")
        self.engine = engine
        self.notify = notify
        self.pi = 0               # selected packet
        self.mi = 0               # selected message
        self._loading = False
        self._fire_index = 0
        self._shown_run = None

        mid = QSplitter(Qt.Orientation.Vertical)
        mid.addWidget(self._build_packet())
        mid.addWidget(self._build_log())
        mid.setSizes([470, 330])
        mid.setChildrenCollapsible(False)

        split = QSplitter(Qt.Orientation.Horizontal)
        split.addWidget(self._build_left())
        split.addWidget(mid)
        split.addWidget(self._build_form())
        split.setSizes([260, 860, 290])
        split.setChildrenCollapsible(False)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.addWidget(split)
        self.refresh()

    # ------------------------------------------------------------- helpers
    @property
    def queue(self):
        return self.engine.state.queue

    def _packet(self) -> Packet | None:
        return self.queue.packets[self.pi] if 0 <= self.pi < len(self.queue.packets) else None

    def _message(self) -> Message | None:
        p = self._packet()
        return p.messages[self.mi] if p and 0 <= self.mi < len(p.messages) else None

    def _fail(self, error: Exception) -> None:
        self.notify(str(error), True)

    # ------------------------------------------------------------- building
    def _build_left(self) -> QFrame:
        frame, lay = panel()
        frame.setMinimumWidth(250)
        self.count_label = muted()
        lay.addLayout(row(h2("Packet queue"), None, self.count_label, stretch_last=False))

        self.plist = QListWidget()
        self.plist.setObjectName("cards")
        self.plist.setWordWrap(True)
        self.plist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.plist.currentRowChanged.connect(self._packet_selected)
        lay.addWidget(self.plist, 1)

        lay.addLayout(row(button("Add packet", self.add_packet),
                          button("Duplicate", self.duplicate_packet), stretch_last=False))
        lay.addLayout(row(button("Move up", lambda: self.move_packet(-1)),
                          button("Move down", lambda: self.move_packet(1)), stretch_last=False))
        lay.addLayout(row(button("Remove", self.remove_packet),
                          button("Clear queue", self.clear_queue), stretch_last=False))

        self.reset_first = QCheckBox("Send reset packet first")
        self.reset_first.toggled.connect(self._reset_first_toggled)
        lay.addWidget(self.reset_first)
        self.fire_btn = button("Fire queue", self.fire_queue, primary=True)
        lay.addWidget(self.fire_btn)
        self.next_btn = button("Fire next", self.fire_next)
        lay.addWidget(self.next_btn)
        return frame

    def _build_packet(self) -> QFrame:
        frame, lay = panel()
        self.packet_frame = frame
        n = self.notify
        self.packet_title = h2("Packet")
        self.size_label = muted()
        self.size_label.setWordWrap(False)
        lay.addLayout(row(self.packet_title, None, self.size_label, stretch_last=False))

        self.f_session = TextField(_session, str, lambda v: self._set_packet("session", v), n, True)
        self.f_sequence = TextField(lambda t: parse_int(t, 0, U64, "Sequence number"), str,
                                    lambda v: self._set_packet("sequence", v), n, True)
        self.f_count = TextField(lambda t: parse_int(t, 0, U16, "Message count"), str,
                                 lambda v: self._set_packet("count", v), n, True)
        lay.addLayout(grid(3, labelled("Session", self.f_session),
                           labelled("Sequence number", self.f_sequence),
                           labelled("Message count", self.f_count)))
        self.auto = QCheckBox("Fill sequence number and message count automatically")
        self.auto.toggled.connect(self._auto_toggled)
        lay.addWidget(self.auto)

        lay.addWidget(label("Ethernet, IP and UDP headers", "h3"))
        specs = [("dst_mac", "Destination MAC", lambda t: format_mac(parse_mac(t))),
                 ("dst_ip", "Destination IP", lambda t: format_ip(parse_ip(t))),
                 ("dst_port", "Destination port", parse_port),
                 ("src_mac", "Source MAC", lambda t: format_mac(parse_mac(t))),
                 ("src_ip", "Source IP", lambda t: format_ip(parse_ip(t))),
                 ("src_port", "Source port", parse_port)]
        self.h_fields: dict[str, TextField] = {}
        cells = []
        for attr, text, parse in specs:
            f = TextField(parse, str, lambda v, a=attr: self._set_header(a, v), n, True)
            self.h_fields[attr] = f
            cells.append(labelled(text, f))
        lay.addLayout(grid(3, *cells))
        self.same_headers = QCheckBox("Use these headers for every packet in the queue")
        self.same_headers.toggled.connect(self._same_headers_toggled)
        lay.addWidget(self.same_headers)

        self.table = QTableWidget(0, len(MESSAGE_COLUMNS))
        self.table.setHorizontalHeaderLabels(MESSAGE_COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.setFont(mono_font())
        header = self.table.horizontalHeader()
        header.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.itemSelectionChanged.connect(self._message_selected)
        self.table.setMinimumHeight(110)
        lay.addWidget(self.table, 1)
        lay.addLayout(row(button("Add message", self.add_message),
                          button("Duplicate message", self.duplicate_message),
                          button("Remove message", self.remove_message)))
        return frame

    def _build_log(self) -> QFrame:
        frame, lay = panel()
        self.run_label = muted("No run yet")
        self.run_label.setWordWrap(False)
        self.events_chip = label("0 events", "chip")
        self.drop_chip = label("", "chipWarn")
        self.drop_chip.hide()
        lay.addLayout(row(h2("Event and latency log"), self.run_label, None, self.drop_chip,
                          self.events_chip, button("Open run folder", self.open_run_folder),
                          button("Export log", self.export_log), stretch_last=False))
        self.log_model = LogModel(self)
        self.log_view = QTableView()
        self.log_view.setModel(self.log_model)
        self.log_view.verticalHeader().setVisible(False)
        self.log_view.verticalHeader().setDefaultSectionSize(26)
        self.log_view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.log_view.setWordWrap(False)
        header = self.log_view.horizontalHeader()
        header.setStretchLastSection(True)
        for i, width in enumerate(LOG_WIDTHS):
            self.log_view.setColumnWidth(i, width)
        self.log_view.setMinimumHeight(120)
        lay.addWidget(self.log_view, 1)
        lay.addWidget(muted("Since input is measured from the most recent input event and "
                            "restarts at each new one."))
        return frame

    def _build_form(self) -> QFrame:
        frame, lay = panel()
        frame.setMinimumWidth(270)
        self.form_frame = frame
        self.form_title = h2("Message")
        lay.addWidget(self.form_title)
        inner = QWidget()
        inner.setObjectName("formBody")
        self.form = QFormLayout(inner)
        self.form.setContentsMargins(0, 0, 6, 0)
        self.form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapAllRows)
        self.form.setVerticalSpacing(6)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(inner)
        lay.addWidget(scroll, 1)

        self.f_type = QComboBox()
        for code, (name, _) in MSG_TYPES.items():
            self.f_type.addItem(f"{code} · {name}", code)
        self.f_type.currentIndexChanged.connect(self._type_changed)
        self.form.addRow(label("Message type", "fieldLabel"), self.f_type)

        self.m_fields: dict[str, QWidget] = {}

        def text(attr, title, parse, fmt=str):
            w = TextField(parse, fmt, lambda v, a=attr: self._set_message(a, v), self.notify, True)
            self.m_fields[attr] = w
            self.form.addRow(label(title, "fieldLabel"), w)

        def combo(attr, title, options):
            w = QComboBox()
            for shown, value in options:
                w.addItem(shown, value)
            w.currentIndexChanged.connect(lambda _i, a=attr, c=w: self._combo_changed(a, c))
            self.m_fields[attr] = w
            self.form.addRow(label(title, "fieldLabel"), w)

        def integer(lo, hi, name):
            return lambda t: parse_int(t, lo, hi, name)

        yes_no = [("Yes", "Y"), ("No", "N")]
        text("order_id", "Order ID (hex)", itch.parse_order_id, itch.format_order_id)
        text("order_book_id", "Order book ID", integer(0, U32, "Order book ID"))
        combo("side", "Side", [("Buy", "B"), ("Sell", "S")])
        text("quantity", "Quantity", integer(0, U64, "Quantity"))
        text("price", "Price (raw)", integer(I32_MIN, I32_MAX, "Price"))
        text("book_position", "Book position", integer(0, U32, "Book position"))
        text("lot_type", "Lot type", integer(0, U8, "Lot type"))
        text("exchange_order_type", "Exchange order type",
             integer(0, U16, "Exchange order type"))
        text("participant_id", "Participant ID", _alpha7("Participant ID"))
        text("counterparty_id", "Counterparty ID", _alpha7("Counterparty ID"))
        text("match_id", "Match ID (hex)", itch.parse_match_id, itch.format_match_id)
        text("trade_price", "Trade price (raw)", integer(I32_MIN, I32_MAX, "Trade price"))
        combo("occurred_at_cross", "Occurred at cross", yes_no)
        combo("printable", "Printable", yes_no)
        text("timestamp_ns", "Timestamp (ns)", integer(0, U32, "Timestamp"))
        text("second", "Second (Unix time)", integer(0, U32, "Second"))
        return frame

    # ------------------------------------------------------------ refreshing
    def refresh(self) -> None:
        q = self.queue
        self.pi = max(0, min(self.pi, len(q.packets) - 1))
        p = self._packet()
        self.mi = max(0, min(self.mi, len(p.messages) - 1)) if p else 0
        self._loading = True
        try:
            self._fill_list()
            self._fill_packet()
            self._fill_table()
            self._fill_form()
            self.reset_first.setChecked(self.engine.state.settings.reset_first)
        finally:
            self._loading = False

    def _fill_list(self) -> None:
        q = self.queue
        self.count_label.setText(f"{len(q.packets)} packet{'' if len(q.packets) == 1 else 's'}")
        self.plist.clear()
        for i, p in enumerate(q.packets):
            status = "Sent" if p.status == "sent" else "Queued"
            plural = "" if p.count == 1 else "s"
            self.plist.addItem(f"Packet {i + 1}   ·   {status}\n"
                               f"seq {p.sequence} · {p.count} msg{plural} · "
                               f"{p.frame_length()} bytes\n{p.type_summary()}")
        if q.packets:
            self.plist.setCurrentRow(self.pi)

    def _fill_packet(self) -> None:
        p = self._packet()
        self.packet_frame.setEnabled(p is not None)
        if p is None:
            self.packet_title.setText("No packet selected")
            self.size_label.setText("")
            return
        n = len(p.messages)
        self.packet_title.setText(f"Packet {self.pi + 1}")
        size = f"{n} message{'' if n == 1 else 's'} · {p.frame_length()}-byte frame before FCS"
        if p.frame_length() > 1514:
            size += " · over the 1514-byte standard maximum"
        self.size_label.setText(size)
        self.f_session.set_value(p.session)
        self.f_sequence.set_value(p.sequence)
        self.f_count.set_value(p.count)
        self.auto.setChecked(p.auto)
        self.f_count.setReadOnly(p.auto)
        self.f_sequence.setReadOnly(p.auto and self.pi > 0)
        h = self.queue.headers_for(p)
        for attr, f in self.h_fields.items():
            f.set_value(getattr(h, attr))
        self.same_headers.setChecked(self.queue.same_headers)

    def _fill_table(self) -> None:
        p = self._packet()
        messages = p.messages if p else []
        self.table.setRowCount(len(messages))
        for r, m in enumerate(messages):
            dash = "–"
            cells = [str(p.sequence + r), m.msg_type,
                     itch.format_order_id(m.order_id) if m.uses("order_id") else dash,
                     str(m.order_book_id) if m.uses("order_book_id") else dash,
                     m.side if m.uses("side") else dash,
                     str(m.quantity) if m.uses("quantity") else dash,
                     str(m.price) if m.uses("price") else dash]
            for c, text in enumerate(cells):
                self.table.setItem(r, c, QTableWidgetItem(text))
        if messages:
            self.table.selectRow(self.mi)

    def _fill_form(self) -> None:
        m = self._message()
        self.form_frame.setEnabled(m is not None)
        if m is None:
            self.form_title.setText("No message selected")
            return
        p = self._packet()
        self.form_title.setText(f"Message {self.mi + 1} of {len(p.messages)}")
        self.f_type.setCurrentIndex(self.f_type.findData(m.msg_type))
        executed = m.msg_type in ("E", "C")
        for attr, w in self.m_fields.items():
            self.form.setRowVisible(w, m.uses(attr))
            value = getattr(m, attr)
            if isinstance(w, QComboBox):
                w.setCurrentIndex(max(0, w.findData(value)))
            else:
                w.set_value(value)
        self.form.labelForField(self.m_fields["quantity"]).setText(
            "Executed quantity" if executed else "Quantity")
        self.form.labelForField(self.m_fields["participant_id"]).setText(
            "Participant ID, owner" if executed else "Participant ID")

    # --------------------------------------------------------------- editing
    def _edited(self) -> None:
        self.queue.renumber()
        self.refresh()
        self.changed.emit()

    def _packet_selected(self, index: int) -> None:
        if self._loading or index < 0:
            return
        self.pi, self.mi = index, 0
        self.refresh()

    def _message_selected(self) -> None:
        if self._loading:
            return
        rows = self.table.selectionModel().selectedRows()
        if rows:
            self.mi = rows[0].row()
            self._loading = True
            try:
                self._fill_form()
            finally:
                self._loading = False

    def _set_packet(self, attr: str, value) -> None:
        p = self._packet()
        if p is not None:
            setattr(p, attr, value)
            self._edited()

    def _auto_toggled(self, on: bool) -> None:
        if not self._loading:
            self._set_packet("auto", on)

    def _set_header(self, attr: str, value) -> None:
        p = self._packet()
        if p is not None:
            setattr(self.queue.headers_for(p), attr, value)
            self._edited()

    def _same_headers_toggled(self, on: bool) -> None:
        if self._loading:
            return
        q = self.queue
        if not on:
            # Start every packet from the shared values so nothing changes on the wire.
            for p in q.packets:
                p.headers = type(q.shared_headers).from_dict(q.shared_headers.to_dict())
        q.same_headers = on
        self._edited()

    def _reset_first_toggled(self, on: bool) -> None:
        if not self._loading:
            self.engine.state.settings.reset_first = on
            self.changed.emit()

    def _set_message(self, attr: str, value) -> None:
        m = self._message()
        if m is not None:
            setattr(m, attr, value)
            self._edited()

    def _combo_changed(self, attr: str, combo: QComboBox) -> None:
        if not self._loading:
            self._set_message(attr, combo.currentData())

    def _type_changed(self, _index: int) -> None:
        if not self._loading:
            self._set_message("msg_type", self.f_type.currentData())

    # ----------------------------------------------------- queue operations
    def add_packet(self) -> None:
        q, cur = self.queue, self._packet()
        new = Packet(session=cur.session if cur else "SESSION001")
        new.headers = type(q.shared_headers).from_dict(
            (cur.headers if cur else q.shared_headers).to_dict())
        template = cur.messages[-1] if cur and cur.messages else Message()
        new.messages.append(Message.from_dict(template.to_dict()))
        self.pi = min(self.pi + 1, len(q.packets))
        q.packets.insert(self.pi, new)
        self.mi = 0
        self._edited()

    def duplicate_packet(self) -> None:
        cur = self._packet()
        if cur is None:
            return
        self.pi += 1
        self.queue.packets.insert(self.pi, cur.copy())
        self._edited()

    def remove_packet(self) -> None:
        if self._packet() is not None:
            del self.queue.packets[self.pi]
            self._edited()

    def move_packet(self, step: int) -> None:
        q, j = self.queue.packets, self.pi + step
        if self._packet() is not None and 0 <= j < len(q):
            q[self.pi], q[j] = q[j], q[self.pi]
            self.pi = j
            self._edited()

    def clear_queue(self) -> None:
        if not self.queue.packets:
            return
        answer = QMessageBox.question(self, "Clear queue",
                                      "Remove every packet from the queue?")
        if answer == QMessageBox.StandardButton.Yes:
            self.queue.packets.clear()
            self.pi = self.mi = 0
            self._edited()

    def _insert_message(self, message: Message) -> None:
        p = self._packet()
        if p is None:
            return
        self.mi = min(self.mi + 1, len(p.messages))
        p.messages.insert(self.mi, message)
        self._edited()

    def add_message(self) -> None:
        """A fresh Add Order, keeping the order book and side of the selected message."""
        cur = self._message()
        self._insert_message(Message(order_book_id=cur.order_book_id if cur else 0,
                                     side=cur.side if cur else "B"))

    def duplicate_message(self) -> None:
        cur = self._message()
        if cur is not None:
            self._insert_message(Message.from_dict(cur.to_dict()))

    def remove_message(self) -> None:
        p = self._packet()
        if p is not None and self._message() is not None:
            del p.messages[self.mi]
            self._edited()

    # ---------------------------------------------------------------- firing
    def fire_queue(self) -> None:
        eng = self.engine
        try:
            if not eng.connected:
                raise RuntimeError("Not connected. Press Connect first.")
            if not self.queue.packets:
                raise ValueError("The queue is empty.")
            eng.validate_queue()
            eng.new_run()
            eng.rearm()
            if eng.state.settings.reset_first:
                eng.send_reset()
        except (ValueError, RuntimeError, OSError) as e:
            self._fail(e)
            return
        self._fire_index = 0
        self._set_firing(True)
        self._fire_step()

    def _fire_step(self) -> None:
        eng = self.engine
        gap = eng.state.settings.packet_gap_ms
        total = len(self.queue.packets)
        try:
            while self._fire_index < total and eng.connected:
                eng.send_packet(self._fire_index)
                self._fire_index += 1
                if gap > 0 and self._fire_index < total:
                    QTimer.singleShot(gap, self._fire_step)
                    self._refresh_statuses()
                    return
        except (ValueError, RuntimeError, OSError) as e:
            self._fail(e)
        self._set_firing(False)
        self._refresh_statuses()
        self.notify(f"Sent {self._fire_index} of {total} packets.", False)

    def fire_next(self) -> None:
        try:
            if not self.engine.connected:
                raise RuntimeError("Not connected. Press Connect first.")
            index = self.engine.fire_next()
        except (ValueError, RuntimeError, OSError) as e:
            self._fail(e)
            return
        if index is None:
            self.notify("The queue is empty.", True)
            return
        self.pi, self.mi = index, 0
        self.refresh()
        self.notify(f"Sent packet {index + 1}.", False)

    def _set_firing(self, firing: bool) -> None:
        self.fire_btn.setEnabled(not firing)
        self.next_btn.setEnabled(not firing)

    def _refresh_statuses(self) -> None:
        self._loading = True
        try:
            self._fill_list()
        finally:
            self._loading = False

    # ------------------------------------------------------------------- log
    def on_pump(self, rows) -> None:
        """Called by the main window after each poll of the transport."""
        run = self.engine.run
        if run is not None and run is not self._shown_run:
            self._shown_run = run
            self.log_model.set_rows(run.rows)
            self.log_view.scrollToBottom()
        elif rows:
            bar = self.log_view.verticalScrollBar()
            at_bottom = bar.value() >= bar.maximum() - 2
            self.log_model.append(rows)
            if at_bottom:
                self.log_view.scrollToBottom()
        if run is not None:
            self.run_label.setText(f"{run.config.name} · {run.config.clock_mhz:g} MHz · "
                                   f"{run.sent_frames} sent")
        count = len(self.log_model.rows)
        set_chip(self.events_chip, f"{count:,} event{'' if count == 1 else 's'}")
        dropped = self.engine.transport.stats()[1] if self.engine.transport else 0
        if dropped:
            self.drop_chip.setText(f"{dropped:,} dropped by capture")
        self.drop_chip.setVisible(bool(dropped))

    def open_run_folder(self) -> None:
        run = self._shown_run
        if run is None:
            self.notify("There is no run yet.", True)
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(run.dir)))

    def export_log(self) -> None:
        if not self.log_model.rows:
            self.notify("There are no events to export.", True)
            return
        name = f"{self._shown_run.name}.csv" if self._shown_run else "events.csv"
        path, _ = QFileDialog.getSaveFileName(self, "Export log", name, "CSV files (*.csv)")
        if path:
            try:
                export_rows(self.log_model.rows, path)
            except OSError as e:
                self._fail(e)
            else:
                self.notify(f"Log exported to {path}", False)
