"""Connection page: which adapter to use, where FPGA events arrive, the reset packet."""

from __future__ import annotations

from PySide6.QtCore import QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QVBoxLayout, QWidget

from .. import pcapio
from ..engine import Engine
from ..frames import parse_port
from ..model import SIM_DEVICE
from .widgets import (TextField, button, grid, h2, label, labelled, muted, panel, parse_int,
                      row, set_chip)


def _hex_bytes(text: str) -> str:
    cleaned = "".join(text.replace(",", " ").replace("0x", "").replace(":", " ").split())
    try:
        raw = bytes.fromhex(cleaned)
    except ValueError:
        raise ValueError("Reset payload must be hex bytes, e.g. 52 45 53 45 54") from None
    return " ".join(f"{b:02x}" for b in raw)


class ConnectionPage(QWidget):
    changed = Signal()
    toggle_requested = Signal()

    def __init__(self, engine: Engine, notify):
        super().__init__()
        self.setObjectName("page")
        self.engine = engine
        self.notify = notify
        self._loading = False
        s = engine.state.settings
        n = notify

        frame, lay = panel(12)
        frame.setMaximumWidth(760)
        lay.addWidget(h2("Adapter"))
        self.device = QComboBox()
        self.device.currentIndexChanged.connect(self._device_changed)
        lay.addLayout(row(labelled("Send and receive on", self.device), stretch_last=False))
        self.device_note = muted()
        lay.addWidget(self.device_note)
        self.connect_btn = button("Connect", self.toggle_requested.emit, primary=True)
        self.status_chip = label("Not connected", "chip")
        lay.addLayout(row(self.connect_btn, button("Refresh adapters", self.refresh_devices),
                          self.status_chip))

        lay.addWidget(h2("FPGA events"))
        self.f_port = TextField(parse_port, str, lambda v: self._set("telemetry_port", v), n, True)
        self.f_filter = TextField(lambda t: t.strip(), str,
                                  lambda v: self._set("extra_filter", v), n, True)
        self.f_filter.setPlaceholderText("optional, e.g. src host 192.168.1.20")
        lay.addLayout(grid(2, labelled("UDP destination port of event packets", self.f_port),
                           labelled("Extra capture filter", self.f_filter)))

        lay.addWidget(h2("Sending"))
        self.f_gap = TextField(lambda t: parse_int(t, 0, 60000, "Pause"), str,
                               lambda v: self._set("packet_gap_ms", v), n, True)
        lay.addLayout(grid(2, labelled("Pause between packets when firing the queue (ms)",
                                       self.f_gap), QWidget()))

        lay.addWidget(h2("Reset packet"))
        self.f_reset_port = TextField(parse_port, str,
                                      lambda v: self._set("reset_dst_port", v), n, True)
        self.f_reset_payload = TextField(_hex_bytes, str,
                                         lambda v: self._set("reset_payload_hex", v), n, True)
        lay.addLayout(grid(2, labelled("UDP destination port", self.f_reset_port),
                           labelled("UDP payload (hex bytes)", self.f_reset_payload)))
        lay.addWidget(muted("Sent as one UDP packet using the queue's shared Ethernet and IP "
                            "headers. Set this to whatever your reset module looks for."))

        lay.addWidget(h2("Data folder"))
        self.folder = muted(str(engine.data_dir))
        lay.addLayout(row(self.folder, None, button("Open folder", self.open_folder),
                          stretch_last=False))
        lay.addWidget(muted("Adapter, port and filter changes take effect the next time you "
                            "connect."))
        lay.addStretch(1)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(16, 16, 16, 16)
        col = QVBoxLayout()
        col.addWidget(frame)
        outer.addLayout(col)
        outer.addStretch(1)

        self.f_port.set_value(s.telemetry_port)
        self.f_filter.set_value(s.extra_filter)
        self.f_gap.set_value(s.packet_gap_ms)
        self.f_reset_port.set_value(s.reset_dst_port)
        self.f_reset_payload.set_value(s.reset_payload_hex)
        self.refresh_devices()

    def _set(self, attr: str, value) -> None:
        setattr(self.engine.state.settings, attr, value)
        self.changed.emit()

    def refresh_devices(self) -> None:
        s = self.engine.state.settings
        self._loading = True
        try:
            self.device.clear()
            self.device.addItem("Simulated FPGA (no hardware)", SIM_DEVICE)
            note = ""
            try:
                devices = pcapio.list_devices()
            except (pcapio.PcapError, OSError) as e:
                devices, note = [], str(e)
            for name, description in devices:
                self.device.addItem(f"{description}  —  {name}" if description else name, name)
            if not devices and not note:
                note = ("No adapters were found. On Windows, check that Npcap is installed; "
                        "on Linux, run with permission to capture.")
            index = self.device.findData(s.device)
            if index < 0:
                self.device.addItem(f"{s.device}  (saved, not found)", s.device)
                index = self.device.count() - 1
            self.device.setCurrentIndex(index)
            self.device_note.setText(note)
            self.device_note.setVisible(bool(note))
        finally:
            self._loading = False

    def _device_changed(self, _index: int) -> None:
        if not self._loading and self.device.currentData() is not None:
            self._set("device", self.device.currentData())

    def device_label(self) -> str:
        return self.device.currentText().split("  —  ")[0]

    def show_status(self, connected: bool, text: str) -> None:
        self.connect_btn.setText("Disconnect" if connected else "Connect")
        set_chip(self.status_chip, text, "chipOn" if connected else "chip")

    def open_folder(self) -> None:
        self.engine.data_dir.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.engine.data_dir)))
