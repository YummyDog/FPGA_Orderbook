"""Shared look and small building blocks for the pages."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QFontDatabase
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QPushButton, QVBoxLayout, QWidget)

INK = "#17212B"
GROUND = "#EEF1F4"
LINE = "#CBD3DC"
MUTED = "#4A5866"
ACCENT = "#1B56B3"
REFERENCE_BG = "#E6EEFA"

QSS = """
QWidget { color: #17212B; font-size: 10pt; }
QMainWindow, QWidget#page { background: #EEF1F4; }
QWidget#topbar { background: #17212B; }
QWidget#topbar QLabel { color: #FFFFFF; }
QWidget#topbar QLabel#status { color: #C9D3DD; }
QWidget#topbar QPushButton { background: #17212B; color: #FFFFFF; border: 1px solid #C9D3DD; }
QWidget#topbar QPushButton:hover { background: #24313F; }
QLabel#title { font-size: 12pt; font-weight: 600; }
QFrame#panel { background: #FFFFFF; border: 1px solid #CBD3DC; border-radius: 6px; }
QLabel#h2 { font-size: 11pt; font-weight: 600; }
QLabel#h3 { font-weight: 600; }
QLabel#fieldLabel { color: #4A5866; font-size: 9pt; font-weight: 600; }
QLabel#muted { color: #4A5866; }
QLabel#chip { background: #E3E8ED; border-radius: 9px; padding: 2px 10px; font-size: 9pt;
              font-weight: 600; }
QLabel#chipOn { background: #D9EFEB; color: #0A4F47; border-radius: 9px; padding: 2px 10px;
                font-size: 9pt; font-weight: 600; }
QLabel#chipWarn { background: #FBE6D6; color: #7A3200; border-radius: 9px; padding: 2px 10px;
                  font-size: 9pt; font-weight: 600; }
QPushButton { min-height: 30px; padding: 0 14px; border: 1px solid #7D8B99; border-radius: 4px;
              background: #FFFFFF; font-weight: 600; }
QPushButton:hover { background: #F3F5F7; }
QPushButton:pressed { background: #E3E8ED; }
QPushButton:disabled { color: #8A96A3; border-color: #CBD3DC; }
QPushButton#primary { background: #1B56B3; color: #FFFFFF; border: 0; min-height: 34px; }
QPushButton#primary:hover { background: #174A9C; }
QPushButton#primary:disabled { background: #9DB4D8; color: #FFFFFF; }
QLineEdit, QComboBox { min-height: 28px; padding: 0 8px; border: 1px solid #7D8B99;
                       border-radius: 4px; background: #FFFFFF; selection-background-color: #1B56B3; }
QLineEdit:focus, QComboBox:focus { border: 2px solid #1B56B3; }
QLineEdit:read-only { background: #EEF1F4; color: #4A5866; }
QLineEdit[invalid="true"] { border: 2px solid #A84300; background: #FFF6EF; }
QCheckBox { spacing: 8px; }
QListWidget, QTableView, QTableWidget { background: #FFFFFF; border: 1px solid #CBD3DC;
                                        border-radius: 4px; gridline-color: #E3E8ED;
                                        selection-background-color: #1B56B3;
                                        selection-color: #FFFFFF; }
QListWidget#cards { border: 0; background: #FFFFFF; }
QListWidget#cards::item { border: 1px solid #CBD3DC; border-radius: 4px; padding: 8px 10px;
                          margin: 3px 0; color: #17212B; }
QListWidget#cards::item:selected { background: #17212B; color: #FFFFFF; border-color: #17212B; }
QHeaderView::section { background: #FFFFFF; color: #4A5866; font-size: 9pt; font-weight: 600;
                       border: 0; border-bottom: 1px solid #CBD3DC; padding: 6px 8px; }
QTabWidget::pane { border: 0; }
QTabBar { background: #FFFFFF; }
QTabBar::tab { background: #FFFFFF; color: #4A5866; font-weight: 600; padding: 10px 18px;
               border: 0; border-bottom: 3px solid #FFFFFF; }
QTabBar::tab:selected { color: #17212B; border-bottom: 3px solid #1B56B3; }
QSplitter::handle { background: #EEF1F4; }
QScrollArea, QWidget#formBody { background: #FFFFFF; }
QStatusBar { background: #FFFFFF; border-top: 1px solid #CBD3DC; }
"""


def mono_font():
    return QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)


def panel(spacing: int = 10) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("panel")
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(16, 14, 16, 14)
    lay.setSpacing(spacing)
    return frame, lay


def label(text: str, name: str = "") -> QLabel:
    lab = QLabel(text)
    if name:
        lab.setObjectName(name)
    return lab


def h2(text: str) -> QLabel:
    return label(text, "h2")


def muted(text: str = "") -> QLabel:
    lab = label(text, "muted")
    lab.setWordWrap(True)
    return lab


def button(text: str, slot=None, primary: bool = False) -> QPushButton:
    b = QPushButton(text)
    if primary:
        b.setObjectName("primary")
    if slot is not None:
        b.clicked.connect(slot)
    return b


def row(*widgets, stretch_last: bool = True) -> QHBoxLayout:
    lay = QHBoxLayout()
    lay.setSpacing(8)
    for w in widgets:
        if w is None:
            lay.addStretch(1)
        elif isinstance(w, QWidget):
            lay.addWidget(w)
        else:
            lay.addLayout(w)
    if stretch_last and widgets and widgets[-1] is not None:
        lay.addStretch(1)
    return lay


def labelled(text: str, widget: QWidget) -> QWidget:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(3)
    lab = label(text, "fieldLabel")
    lay.addWidget(lab)
    lay.addWidget(widget)
    box.field_label = lab
    return box


def grid(columns: int, *cells: QWidget) -> QGridLayout:
    g = QGridLayout()
    g.setHorizontalSpacing(10)
    g.setVerticalSpacing(8)
    for i, cell in enumerate(cells):
        g.addWidget(cell, i // columns, i % columns)
    for c in range(columns):
        g.setColumnStretch(c, 1)
    return g


def set_chip(lab: QLabel, text: str, kind: str = "chip") -> None:
    lab.setText(text)
    if lab.objectName() != kind:
        lab.setObjectName(kind)
        lab.style().unpolish(lab)
        lab.style().polish(lab)


def parse_int(text: str, lo: int, hi: int, name: str) -> int:
    t = text.strip().replace(",", "").replace("_", "").replace(" ", "")
    try:
        value = int(t, 16) if t.lower().startswith(("0x", "-0x")) else int(t)
    except ValueError:
        raise ValueError(f"{name} must be a whole number") from None
    if not lo <= value <= hi:
        raise ValueError(f"{name} must be between {lo} and {hi}")
    return value


class TextField(QLineEdit):
    """A text box that parses on commit and reports problems instead of raising.

    parse(text) returns the value or raises ValueError; fmt(value) gives the
    text to show; on_commit(value) stores it. notify(message) shows problems.
    """

    def __init__(self, parse, fmt, on_commit, notify, mono: bool = False):
        super().__init__()
        self._parse, self._fmt, self._on_commit, self._notify = parse, fmt, on_commit, notify
        self._shown = ""
        if mono:
            self.setFont(mono_font())
        self.editingFinished.connect(self._commit)

    def set_value(self, value) -> None:
        self._shown = self._fmt(value)
        self.setText(self._shown)
        self._mark(False)

    def _mark(self, invalid: bool) -> None:
        if bool(self.property("invalid")) != invalid:
            self.setProperty("invalid", invalid)
            self.style().unpolish(self)
            self.style().polish(self)

    def _commit(self) -> None:
        if self.isReadOnly() or self.text() == self._shown:
            return
        try:
            value = self._parse(self.text())
        except ValueError as e:
            self._mark(True)
            self._notify(str(e))
            return
        self._mark(False)
        self._shown = self.text()
        self._on_commit(value)


ALIGN_RIGHT = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
