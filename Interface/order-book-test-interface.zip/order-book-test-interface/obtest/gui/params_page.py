"""FPGA parameters page: describe each build and compare latency between them.

Nothing on this page is sent to the FPGA. The clock frequency converts cycle
counts to nanoseconds; the rest is stored with each run as labels.
"""

from __future__ import annotations

import csv

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QFileDialog, QFrame, QHBoxLayout,
                               QHeaderView, QListWidget, QSplitter, QTableWidget,
                               QTableWidgetItem, QWidget)

from ..engine import Engine
from ..model import FpgaConfig
from ..runlog import latency_by_config
from .widgets import (TextField, button, grid, h2, label, labelled, mono_font, muted, panel,
                      parse_int, row, set_chip)

HASH_CHOICES = ["XOR mask (hash65)", "XOR mask, table 0 identity"]


def _clock(text: str) -> float:
    try:
        value = float(text.strip().replace(",", ""))
    except ValueError:
        raise ValueError("Clock frequency must be a number in MHz") from None
    if not 0 < value <= 10000:
        raise ValueError("Clock frequency must be between 0 and 10000 MHz")
    return value


def _name(text: str) -> str:
    t = text.strip()
    if not t:
        raise ValueError("Configuration name cannot be empty")
    return t


def _ns(value) -> str:
    return "–" if value is None else f"{value:,.1f} ns"


class ParamsPage(QWidget):
    changed = Signal()

    def __init__(self, engine: Engine, notify):
        super().__init__()
        self.setObjectName("page")
        self.engine = engine
        self.notify = notify
        self.ci = engine.state.active_config
        self._loading = False

        split = QSplitter(Qt.Orientation.Horizontal)
        split.addWidget(self._build_left())
        split.addWidget(self._build_middle())
        split.addWidget(self._build_right())
        split.setSizes([280, 620, 460])
        split.setChildrenCollapsible(False)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.addWidget(split)
        self.refresh()
        self.refresh_stats()

    @property
    def state(self):
        return self.engine.state

    def _config(self) -> FpgaConfig:
        self.ci = max(0, min(self.ci, len(self.state.configs) - 1))
        return self.state.configs[self.ci]

    # ------------------------------------------------------------- building
    def _build_left(self) -> QFrame:
        frame, lay = panel()
        frame.setMinimumWidth(250)
        self.count_label = muted()
        lay.addLayout(row(h2("Configurations"), None, self.count_label, stretch_last=False))
        self.clist = QListWidget()
        self.clist.setObjectName("cards")
        self.clist.setWordWrap(True)
        self.clist.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.clist.currentRowChanged.connect(self._selected)
        lay.addWidget(self.clist, 1)
        lay.addLayout(row(button("Add configuration", self.add_config), stretch_last=False))
        lay.addLayout(row(button("Duplicate", self.duplicate_config),
                          button("Remove", self.remove_config), stretch_last=False))
        return frame

    def _build_middle(self) -> QFrame:
        frame, lay = panel()
        n = self.notify
        self.in_use = label("", "chip")
        self.f_name = TextField(_name, str, lambda v: self._set("name", v), n)
        lay.addLayout(row(labelled("Configuration name", self.f_name), stretch_last=False))

        lay.addWidget(h2("Order hash tables"))
        self.f_tables = TextField(lambda t: parse_int(t, 1, 64, "Number of hash tables"), str,
                                  lambda v: self._set("num_tables", v), n, True)
        self.f_addr = TextField(lambda t: parse_int(t, 1, 32, "Address length"), str,
                                lambda v: self._set("addr_bits", v), n, True)
        self.f_hash = QComboBox()
        self.f_hash.setEditable(True)
        self.f_hash.addItems(HASH_CHOICES)
        self.f_hash.lineEdit().editingFinished.connect(self._hash_changed)
        self.f_hash.activated.connect(lambda _i: self._hash_changed())
        lay.addLayout(grid(3, labelled("Number of hash tables", self.f_tables),
                           labelled("Address length (bits)", self.f_addr),
                           labelled("Hashing function", self.f_hash)))
        self.entries_label = muted()
        self.entries_label.setFont(mono_font())
        lay.addWidget(self.entries_label)

        lay.addWidget(h2("Other parameters"))
        self.other = QTableWidget(0, 2)
        self.other.setHorizontalHeaderLabels(["Parameter", "Value"])
        self.other.verticalHeader().setVisible(False)
        self.other.verticalHeader().setDefaultSectionSize(28)
        self.other.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.other.horizontalHeader().setDefaultAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.other.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.other.itemChanged.connect(self._other_changed)
        self.other.setMinimumHeight(110)
        lay.addWidget(self.other, 1)
        lay.addLayout(row(button("Add parameter", self.add_other),
                          button("Remove parameter", self.remove_other)))

        lay.addWidget(h2("Timing"))
        self.f_clock = TextField(_clock, lambda v: f"{v:g}", lambda v: self._set("clock_mhz", v),
                                 n, True)
        self.cycle_label = label("")
        self.cycle_label.setFont(mono_font())
        lay.addLayout(grid(2, labelled("Clock frequency (MHz)", self.f_clock),
                           labelled("One clock cycle", self.cycle_label)))
        lay.addWidget(muted("Runs are logged under the configuration in use. Nothing here is "
                            "sent to the FPGA; the table settings are labels only."))
        self.use_btn = button("Use for new runs", self.use_config, primary=True)
        lay.addLayout(row(self.use_btn, self.in_use))
        return frame

    def _build_right(self) -> QFrame:
        frame, lay = panel()
        frame.setMinimumWidth(360)
        lay.addWidget(h2("Latency by configuration"))
        self.event_filter = QComboBox()
        self.event_filter.addItem("Input to any later event", "All")
        self.event_filter.addItem("Input to FIFO event", "FIFO")
        self.event_filter.addItem("Input to order event", "Order")
        self.event_filter.addItem("Input to price event", "Price")
        self.event_filter.currentIndexChanged.connect(lambda _i: self.refresh_stats())
        lay.addWidget(labelled("Measured between", self.event_filter))
        self.stats = QTableWidget(0, 5)
        self.stats.setHorizontalHeaderLabels(["Configuration", "Runs", "Events", "Median",
                                              "Worst"])
        self.stats.verticalHeader().setVisible(False)
        self.stats.verticalHeader().setDefaultSectionSize(28)
        self.stats.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.stats.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        header = self.stats.horizontalHeader()
        header.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        lay.addWidget(self.stats, 1)
        lay.addWidget(muted("Calculated from every saved run in the data folder."))
        lay.addLayout(row(button("Refresh", self.refresh_stats),
                          button("Export comparison", self.export_stats)))
        return frame

    # ------------------------------------------------------------ refreshing
    def refresh(self) -> None:
        c = self._config()
        self._loading = True
        try:
            configs = self.state.configs
            self.count_label.setText(f"{len(configs)} saved")
            self.clist.clear()
            for i, cfg in enumerate(configs):
                tables = "table" if cfg.num_tables == 1 else "tables"
                used = "   ·   In use" if i == self.state.active_config else ""
                self.clist.addItem(f"{cfg.name}{used}\n{cfg.num_tables} {tables} · "
                                   f"{cfg.addr_bits}-bit address · {cfg.clock_mhz:g} MHz\n"
                                   f"{cfg.hash_function}")
            self.clist.setCurrentRow(self.ci)

            self.f_name.set_value(c.name)
            self.f_tables.set_value(c.num_tables)
            self.f_addr.set_value(c.addr_bits)
            self.f_hash.setCurrentText(c.hash_function)
            per_table = 2 ** c.addr_bits
            self.entries_label.setText(f"{per_table:,} entries per table · "
                                       f"{per_table * c.num_tables:,} entries in total")
            self.f_clock.set_value(c.clock_mhz)
            self.cycle_label.setText(f"{1000.0 / c.clock_mhz:.4g} ns per cycle")

            self.other.setRowCount(len(c.other))
            for r, (name, value) in enumerate(c.other):
                self.other.setItem(r, 0, QTableWidgetItem(name))
                self.other.setItem(r, 1, QTableWidgetItem(value))

            active = self.ci == self.state.active_config
            set_chip(self.in_use, "In use for new runs" if active else "Not in use",
                     "chipOn" if active else "chip")
            self.use_btn.setEnabled(not active)
        finally:
            self._loading = False

    def refresh_stats(self) -> None:
        rows = latency_by_config(self.engine.data_dir, self.event_filter.currentData())
        self._stats_rows = rows
        self.stats.setRowCount(len(rows))
        for r, s in enumerate(rows):
            cells = [s["config"], str(s["runs"]), f"{s['events']:,}", _ns(s["median_ns"]),
                     _ns(s["worst_ns"])]
            for c, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if c:
                    item.setFont(mono_font())
                self.stats.setItem(r, c, item)

    # --------------------------------------------------------------- editing
    def _edited(self) -> None:
        self.refresh()
        self.changed.emit()

    def _selected(self, index: int) -> None:
        if not self._loading and index >= 0:
            self.ci = index
            self.refresh()

    def _set(self, attr: str, value) -> None:
        setattr(self._config(), attr, value)
        self._edited()

    def _hash_changed(self) -> None:
        if self._loading:
            return
        text = self.f_hash.currentText().strip()
        if text and text != self._config().hash_function:
            self._set("hash_function", text)

    def _other_changed(self, _item) -> None:
        if self._loading:
            return
        rows = []
        for r in range(self.other.rowCount()):
            name, value = self.other.item(r, 0), self.other.item(r, 1)
            rows.append([name.text() if name else "", value.text() if value else ""])
        self._config().other = rows
        self.changed.emit()

    def add_other(self) -> None:
        self._config().other.append(["", ""])
        self._edited()
        last = self.other.rowCount() - 1
        self.other.setCurrentCell(last, 0)
        self.other.editItem(self.other.item(last, 0))

    def remove_other(self) -> None:
        r = self.other.currentRow()
        c = self._config()
        if 0 <= r < len(c.other):
            del c.other[r]
            self._edited()

    def add_config(self) -> None:
        base = self._config().copy()
        names = {c.name for c in self.state.configs}
        n = len(self.state.configs) + 1
        while f"Configuration {n}" in names:
            n += 1
        base.name = f"Configuration {n}"
        self.state.configs.append(base)
        self.ci = len(self.state.configs) - 1
        self._edited()

    def duplicate_config(self) -> None:
        copy = self._config().copy()
        copy.name += " copy"
        self.state.configs.insert(self.ci + 1, copy)
        if self.state.active_config > self.ci:
            self.state.active_config += 1
        self.ci += 1
        self._edited()

    def remove_config(self) -> None:
        if len(self.state.configs) <= 1:
            self.notify("At least one configuration is needed.", True)
            return
        del self.state.configs[self.ci]
        if self.state.active_config > self.ci:
            self.state.active_config -= 1
        elif self.state.active_config == self.ci:
            self.state.active_config = 0
        self._edited()

    def use_config(self) -> None:
        self.state.active_config = self.ci
        self._edited()
        self.notify(f"New runs will be logged under “{self._config().name}”.", False)

    def export_stats(self) -> None:
        if not self._stats_rows:
            self.notify("There are no saved runs to compare yet.", True)
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export comparison",
                                              "latency_by_configuration.csv",
                                              "CSV files (*.csv)")
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["configuration", "runs", "events", "median_ns", "worst_ns",
                            "measured"])
                for s in self._stats_rows:
                    w.writerow([s["config"], s["runs"], s["events"], s["median_ns"],
                                s["worst_ns"], self.event_filter.currentText()])
        except OSError as e:
            self.notify(str(e), True)
        else:
            self.notify(f"Comparison exported to {path}", False)
