"""Table model for the event and latency log."""

from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PySide6.QtGui import QColor, QFont

from ..runlog import LogRow
from .widgets import REFERENCE_BG, mono_font

COLUMNS = ["#", "Event", "Op", "Side", "Data", "Timestamp", "Since input", "Raw payload"]
MONO_COLUMNS = {0, 4, 5, 6, 7}


def since_text(r: LogRow) -> str:
    if r.is_reference:
        return "Reference"
    if r.since_cycles is None:
        return "–"
    if r.since_ns is None:
        return f"{r.since_cycles} cyc"
    return f"{r.since_ns:,.1f} ns · {r.since_cycles} cyc"


class LogModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows: list[LogRow] = []
        self._mono = mono_font()
        self._bold = QFont()
        self._bold.setBold(True)
        self._ref = QColor(REFERENCE_BG)
        self._warn = QColor("#FBE6D6")

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(COLUMNS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return COLUMNS[section]
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        r, c = self.rows[index.row()], index.column()
        if role == Qt.ItemDataRole.DisplayRole:
            if c == 0:
                return str(r.index)
            if c == 1:
                return r.event
            if c == 2:
                return r.op
            if c == 3:
                return r.side
            if c == 4:
                return r.data_decoded
            if c == 5:
                return "" if r.ts is None else str(r.ts)
            if c == 6:
                return "" if r.event == "Malformed" else since_text(r)
            return r.raw_hex
        if role == Qt.ItemDataRole.BackgroundRole:
            if r.is_reference:
                return self._ref
            if r.event == "Malformed":
                return self._warn
        if role == Qt.ItemDataRole.FontRole:
            if c == 1 and r.is_reference:
                return self._bold
            if c in MONO_COLUMNS:
                return self._mono
        return None

    def set_rows(self, rows: list[LogRow]) -> None:
        self.beginResetModel()
        self.rows = list(rows)
        self.endResetModel()

    def append(self, rows: list[LogRow]) -> None:
        if not rows:
            return
        first = len(self.rows)
        self.beginInsertRows(QModelIndex(), first, first + len(rows) - 1)
        self.rows.extend(rows)
        self.endInsertRows()
