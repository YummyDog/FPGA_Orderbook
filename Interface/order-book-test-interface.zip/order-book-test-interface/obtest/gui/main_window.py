"""Main window: top bar, the three pages, and the timers that drive receiving and saving."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QMainWindow, QMessageBox, QTabWidget,
                               QVBoxLayout, QWidget)

from ..engine import Engine
from ..model import SIM_DEVICE
from .connection_page import ConnectionPage
from .params_page import ParamsPage
from .queue_page import QueuePage
from .widgets import QSS, button, label

DEFAULT_DATA_DIR = Path(__file__).resolve().parents[2] / "data"


class MainWindow(QMainWindow):
    def __init__(self, data_dir: Path, auto_connect: bool = True):
        super().__init__()
        self.setWindowTitle("Order Book Test Interface")
        self.engine = Engine(data_dir)

        top = QWidget()
        top.setObjectName("topbar")
        bar = QHBoxLayout(top)
        bar.setContentsMargins(20, 10, 20, 10)
        bar.setSpacing(14)
        bar.addWidget(label("Order Book Test Interface", "title"))
        bar.addStretch(1)
        self.status = label("Not connected", "status")
        bar.addWidget(self.status)
        self.connect_btn = button("Connect", self.toggle_connection)
        bar.addWidget(self.connect_btn)
        bar.addWidget(button("Send reset packet", self.send_reset))

        self.queue_page = QueuePage(self.engine, self.notify)
        self.params_page = ParamsPage(self.engine, self.notify)
        self.connection_page = ConnectionPage(self.engine, self.notify)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.addTab(self.queue_page, "Packet queue")
        self.tabs.addTab(self.params_page, "FPGA parameters")
        self.tabs.addTab(self.connection_page, "Connection")
        self.tabs.currentChanged.connect(self._tab_changed)

        central = QWidget()
        lay = QVBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(top)
        lay.addWidget(self.tabs, 1)
        self.setCentralWidget(central)
        self.statusBar().setSizeGripEnabled(False)

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(400)
        self._save_timer.timeout.connect(self._save)
        for page in (self.queue_page, self.params_page, self.connection_page):
            page.changed.connect(self._save_timer.start)
        self.connection_page.toggle_requested.connect(self.toggle_connection)

        self._pump_timer = QTimer(self)
        self._pump_timer.setInterval(30)
        self._pump_timer.timeout.connect(self.pump)
        self._pump_timer.start()

        self._show_connection()
        if auto_connect and self.engine.state.settings.device == SIM_DEVICE:
            self.toggle_connection()

    # --------------------------------------------------------------- status
    def notify(self, message: str, error: bool = False) -> None:
        self.statusBar().setStyleSheet("color: #7A3200; font-weight: 600;" if error else "")
        self.statusBar().showMessage(message, 12000)

    def _show_connection(self) -> None:
        eng = self.engine
        if eng.connected:
            text = f"Connected · {eng.transport.description}"
        else:
            text = "Not connected"
        self.status.setText(text)
        self.connect_btn.setText("Disconnect" if eng.connected else "Connect")
        self.connection_page.show_status(eng.connected, text)

    def _save(self) -> None:
        try:
            self.engine.save()
        except OSError as e:
            self.notify(f"Could not save settings: {e}", True)

    def _tab_changed(self, index: int) -> None:
        if self.tabs.widget(index) is self.params_page:
            self.params_page.refresh_stats()

    # ----------------------------------------------------------- connection
    def toggle_connection(self) -> None:
        eng = self.engine
        if eng.connected:
            eng.disconnect()
            self.notify("Disconnected.")
        else:
            try:
                eng.connect(self.connection_page.device_label())
            except (RuntimeError, ValueError, OSError) as e:
                self.notify(str(e), True)
                QMessageBox.warning(self, "Could not connect", str(e))
            else:
                self.notify(f"Connected to {eng.transport.description}.")
        self._show_connection()

    def send_reset(self) -> None:
        try:
            if not self.engine.connected:
                raise RuntimeError("Not connected. Press Connect first.")
            self.engine.send_reset()
        except (RuntimeError, ValueError, OSError) as e:
            self.notify(str(e), True)
        else:
            self.notify("Reset packet sent.")

    def pump(self) -> None:
        eng = self.engine
        try:
            rows = eng.pump()
        except OSError as e:
            self.notify(f"Could not write the log: {e}", True)
            rows = []
        self.queue_page.on_pump(rows)
        if eng.transport is not None and eng.transport.error():
            message = eng.transport.error()
            eng.disconnect()
            self._show_connection()
            self.notify(message, True)

    def closeEvent(self, event) -> None:
        self._pump_timer.stop()
        self._save()
        self.engine.disconnect()
        super().closeEvent(event)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Order book test interface")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA_DIR,
                        help="folder for saved settings and runs (default: ./data)")
    args = parser.parse_args(argv)

    app = QApplication(sys.argv[:1])
    app.setStyle("Fusion")
    app.setStyleSheet(QSS)
    window = MainWindow(args.data)
    window.resize(1440, 900)
    window.show()
    return app.exec()
