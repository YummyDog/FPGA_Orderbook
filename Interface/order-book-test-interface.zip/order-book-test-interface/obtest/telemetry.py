"""Decoding of the FPGA's event packets and the latency rule.

Each UDP packet from the FPGA carries one 87-bit event, most significant
field first:

    type (2) | op (2) | data (64) | side (1) | timestamp (18)

87 bits travel in 11 bytes, most significant byte first, with the one spare
bit at the BOTTOM (the last bit of the last byte). In VHDL terms the payload
is `event & '0'`.
"""

from __future__ import annotations

from dataclasses import dataclass

EVENT_BITS = 87
PAYLOAD_LEN = 11
TS_BITS = 18
TS_MOD = 1 << TS_BITS

PRICE, ORDER, INPUT, FIFO = 0, 1, 2, 3
EVENT_NAMES = {PRICE: "Price", ORDER: "Order", INPUT: "Input", FIFO: "FIFO"}
OP_NAMES = {0: "ADD", 1: "EXEC", 2: "REPLACE", 3: "DELETE"}
SIDE_NAMES = {0: "Buy", 1: "Sell"}


@dataclass
class Event:
    raw: bytes
    etype: int
    op: int
    data: int
    side: int
    ts: int

    @property
    def type_name(self) -> str:
        return EVENT_NAMES[self.etype]

    @property
    def op_name(self) -> str:
        return OP_NAMES[self.op]

    @property
    def side_name(self) -> str:
        return SIDE_NAMES[self.side]

    def describe_data(self) -> str:
        """Human-readable data field, by event type."""
        if self.etype == PRICE:
            return f"qty {self.data >> 32} · price {self.data & 0xFFFFFFFF}"
        if self.etype == ORDER:
            return f"{(self.data >> 32) & 0xFFFFFFFF:08x}:{self.data & 0xFFFFFFFF:08x}"
        return f"0x{self.data:016x}"


def decode_event(payload: bytes) -> Event:
    """Decode the first 11 bytes of a UDP payload into an Event."""
    if len(payload) < PAYLOAD_LEN:
        raise ValueError(f"Event payload is {len(payload)} bytes, expected {PAYLOAD_LEN}")
    raw = bytes(payload[:PAYLOAD_LEN])
    v = int.from_bytes(raw, "big") >> 1            # drop the spare bottom bit
    return Event(
        raw=raw,
        etype=(v >> 85) & 0x3,
        op=(v >> 83) & 0x3,
        data=(v >> 19) & 0xFFFFFFFFFFFFFFFF,
        side=(v >> 18) & 0x1,
        ts=v & 0x3FFFF,
    )


def encode_event(etype: int, op: int, data: int, side: int, ts: int) -> bytes:
    """Inverse of decode_event. Used by the software stand-in and the tests."""
    v = ((etype & 0x3) << 85) | ((op & 0x3) << 83) | ((data & 0xFFFFFFFFFFFFFFFF) << 19) \
        | ((side & 0x1) << 18) | (ts & 0x3FFFF)
    return (v << 1).to_bytes(PAYLOAD_LEN, "big")


class LatencyTracker:
    """Latency of each event measured from the most recent input event.

    A new input event becomes the new reference. The timestamp is an 18-bit
    cycle counter, so differences are taken modulo 2**18.
    """

    def __init__(self) -> None:
        self.reference: int | None = None

    def reset(self) -> None:
        self.reference = None

    def update(self, ev: Event) -> int | None:
        """Return cycles since the last input event.

        0 for an input event itself, None if no input event has been seen yet.
        """
        if ev.etype == INPUT:
            self.reference = ev.ts
            return 0
        if self.reference is None:
            return None
        return (ev.ts - self.reference) % TS_MOD


def cycles_to_ns(cycles: int | None, clock_mhz: float) -> float | None:
    if cycles is None or not clock_mhz or clock_mhz <= 0:
        return None
    return cycles * 1000.0 / clock_mhz
