"""ASX Trade ITCH message encoding (spec v3.1, March 2020).

All numeric fields are big-endian. Alpha fields are left-justified and padded
on the right with spaces. Only the messages that change the lit book (plus the
Seconds message) are supported, because that is all the FPGA design handles.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, asdict, fields

# code -> (name, encoded length in bytes)
MSG_TYPES = {
    "A": ("Add Order", 37),
    "F": ("Add Order with participant", 44),
    "E": ("Order Executed", 52),
    "C": ("Order Executed with price", 58),
    "U": ("Order Replace", 36),
    "D": ("Order Delete", 18),
    "T": ("Seconds", 5),
}

# Which Message attributes each type actually puts on the wire. The GUI uses
# this to show only the relevant boxes.
FIELDS_BY_TYPE = {
    "A": ["timestamp_ns", "order_id", "order_book_id", "side", "book_position",
          "quantity", "price", "exchange_order_type", "lot_type"],
    "F": ["timestamp_ns", "order_id", "order_book_id", "side", "book_position",
          "quantity", "price", "exchange_order_type", "lot_type", "participant_id"],
    "E": ["timestamp_ns", "order_id", "order_book_id", "side", "quantity",
          "match_id", "participant_id", "counterparty_id"],
    "C": ["timestamp_ns", "order_id", "order_book_id", "side", "quantity",
          "match_id", "participant_id", "counterparty_id", "trade_price",
          "occurred_at_cross", "printable"],
    "U": ["timestamp_ns", "order_id", "order_book_id", "side", "book_position",
          "quantity", "price", "exchange_order_type"],
    "D": ["timestamp_ns", "order_id", "order_book_id", "side"],
    "T": ["second"],
}

U8, U16, U32, U64 = 0xFF, 0xFFFF, 0xFFFFFFFF, 0xFFFFFFFFFFFFFFFF
I32_MIN, I32_MAX = -(2 ** 31), 2 ** 31 - 1
U96 = 2 ** 96 - 1


def parse_order_id(text: str) -> int:
    """Accept '62018a81:000119dd', '0x62018a81000119dd' or plain hex."""
    t = text.strip().lower().replace(":", "").replace("_", "").replace(" ", "")
    if t.startswith("0x"):
        t = t[2:]
    if not t:
        raise ValueError("Order ID is empty")
    try:
        value = int(t, 16)
    except ValueError:
        raise ValueError("Order ID must be hexadecimal, e.g. 62018a81:000119dd") from None
    if value > U64:
        raise ValueError("Order ID does not fit in 8 bytes")
    return value


def format_order_id(value: int) -> str:
    """Two blocks of four bytes in hex, the way the ASX spec prints them."""
    return f"{(value >> 32) & U32:08x}:{value & U32:08x}"


def parse_match_id(text: str) -> int:
    t = text.strip().lower().replace(":", "").replace("_", "").replace(" ", "")
    if t.startswith("0x"):
        t = t[2:]
    if not t:
        return 0
    try:
        value = int(t, 16)
    except ValueError:
        raise ValueError("Match ID must be hexadecimal") from None
    if value > U96:
        raise ValueError("Match ID does not fit in 12 bytes")
    return value


def format_match_id(value: int) -> str:
    return f"{(value >> 64) & U32:08x}:{(value >> 32) & U32:08x}:{value & U32:08x}"


def _alpha(text: str, width: int, label: str) -> bytes:
    raw = text.encode("latin-1", errors="strict")
    if len(raw) > width:
        raise ValueError(f"{label} is longer than {width} characters")
    return raw.ljust(width, b" ")


def _check(value: int, lo: int, hi: int, label: str) -> int:
    if not lo <= value <= hi:
        raise ValueError(f"{label} must be between {lo} and {hi}")
    return value


@dataclass
class Message:
    """One ITCH message. Unused fields for a given type are simply ignored."""

    msg_type: str = "A"
    timestamp_ns: int = 0
    order_id: int = 0
    order_book_id: int = 0
    side: str = "B"                 # 'B' buy, 'S' sell
    book_position: int = 1
    quantity: int = 0               # executed quantity for E and C
    price: int = 0                  # signed, raw units as sent on the wire
    exchange_order_type: int = 0
    lot_type: int = 2
    participant_id: str = ""        # participant (F) or owner (E, C)
    counterparty_id: str = ""
    match_id: int = 0               # 12 bytes
    trade_price: int = 0
    occurred_at_cross: str = "N"
    printable: str = "Y"
    second: int = 0                 # Seconds message only

    @property
    def name(self) -> str:
        return MSG_TYPES[self.msg_type][0]

    @property
    def length(self) -> int:
        return MSG_TYPES[self.msg_type][1]

    def uses(self, field_name: str) -> bool:
        return field_name in FIELDS_BY_TYPE[self.msg_type]

    def encode(self) -> bytes:
        t = self.msg_type
        if t not in MSG_TYPES:
            raise ValueError(f"Unknown message type {t!r}")
        code = t.encode("ascii")
        if t == "T":
            return struct.pack(">cI", code, _check(self.second, 0, U32, "Second"))

        if self.side not in ("B", "S"):
            raise ValueError("Side must be B or S")
        side = self.side.encode("ascii")
        ts = _check(self.timestamp_ns, 0, U32, "Timestamp")
        oid = _check(self.order_id, 0, U64, "Order ID")
        book = _check(self.order_book_id, 0, U32, "Order book ID")
        qty = _check(self.quantity, 0, U64, "Quantity")

        if t in ("A", "F"):
            out = struct.pack(
                ">cIQIcIQiHB", code, ts, oid, book, side,
                _check(self.book_position, 0, U32, "Book position"), qty,
                _check(self.price, I32_MIN, I32_MAX, "Price"),
                _check(self.exchange_order_type, 0, U16, "Exchange order type"),
                _check(self.lot_type, 0, U8, "Lot type"))
            if t == "F":
                out += _alpha(self.participant_id, 7, "Participant ID")
        elif t in ("E", "C"):
            out = struct.pack(">cIQIcQ", code, ts, oid, book, side, qty)
            out += _check(self.match_id, 0, U96, "Match ID").to_bytes(12, "big")
            out += _alpha(self.participant_id, 7, "Participant ID")
            out += _alpha(self.counterparty_id, 7, "Counterparty ID")
            if t == "C":
                for flag, label in ((self.occurred_at_cross, "Occurred at cross"),
                                    (self.printable, "Printable")):
                    if flag not in ("Y", "N"):
                        raise ValueError(f"{label} must be Y or N")
                out += struct.pack(
                    ">icc", _check(self.trade_price, I32_MIN, I32_MAX, "Trade price"),
                    self.occurred_at_cross.encode("ascii"), self.printable.encode("ascii"))
        elif t == "U":
            out = struct.pack(
                ">cIQIcIQiH", code, ts, oid, book, side,
                _check(self.book_position, 0, U32, "Book position"), qty,
                _check(self.price, I32_MIN, I32_MAX, "Price"),
                _check(self.exchange_order_type, 0, U16, "Exchange order type"))
        else:  # D
            out = struct.pack(">cIQIc", code, ts, oid, book, side)

        assert len(out) == self.length, (t, len(out), self.length)
        return out

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Message":
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})


def decode(data: bytes) -> Message:
    """Decode one ITCH message. Used by the software stand-in and the tests."""
    if not data:
        raise ValueError("Empty message")
    t = chr(data[0])
    if t not in MSG_TYPES:
        raise ValueError(f"Unsupported message type {t!r}")
    if len(data) != MSG_TYPES[t][1]:
        raise ValueError(f"Message {t} should be {MSG_TYPES[t][1]} bytes, got {len(data)}")
    m = Message(msg_type=t)
    if t == "T":
        (m.second,) = struct.unpack(">I", data[1:5])
        return m
    m.timestamp_ns, m.order_id, m.order_book_id, side = struct.unpack(">IQIc", data[1:18])
    m.side = side.decode("ascii")
    if t in ("A", "F"):
        (m.book_position, m.quantity, m.price,
         m.exchange_order_type, m.lot_type) = struct.unpack(">IQiHB", data[18:37])
        if t == "F":
            m.participant_id = data[37:44].decode("latin-1").rstrip()
    elif t in ("E", "C"):
        (m.quantity,) = struct.unpack(">Q", data[18:26])
        m.match_id = int.from_bytes(data[26:38], "big")
        m.participant_id = data[38:45].decode("latin-1").rstrip()
        m.counterparty_id = data[45:52].decode("latin-1").rstrip()
        if t == "C":
            m.trade_price, cross, printable = struct.unpack(">icc", data[52:58])
            m.occurred_at_cross = cross.decode("ascii")
            m.printable = printable.decode("ascii")
    elif t == "U":
        (m.book_position, m.quantity, m.price,
         m.exchange_order_type) = struct.unpack(">IQiH", data[18:36])
    return m
